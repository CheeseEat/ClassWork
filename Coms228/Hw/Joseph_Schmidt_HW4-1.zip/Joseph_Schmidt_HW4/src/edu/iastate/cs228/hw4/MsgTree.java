package edu.iastate.cs228.hw4;

import java.util.Scanner;

/*
 * @author Joseph Schmidt
 * 
 * 228 Hw4 Batinov 4/20/2023
 * 
 * Creates a MsgTree that can be constructed from a given encrypted string. Has a print method that prints out the contents of embedded tree. Has decode method that given a string of
 * binary numbers will use it as pathways for given characters. Also has a statistics method that will print off the space saved and the total length of messages made.
 * 
 */
public class MsgTree {
	
	/*Can use a static char idx to the tree string for recursive
	solution, but it is not strictly necessary*/
	private static int staticCharIdx = 0;
	
	//To help keep track of index for decode method
	static int binaryCount = 0;
	
	//Holding the value of the decoded message
	String decodedMessage = "";
			
	//Contains the char contained in this MsgTree
	public char payloadChar;
	public MsgTree left;
	public MsgTree right;
	
	//Constructor for a single node with null children
	public MsgTree(char payloadChar){
		
		this.payloadChar = payloadChar;
		
	}
	
	/*
	 * Constructor for MsgTree that constructs the tree from a given coding string
	 */
	public MsgTree(String encodingString){
		
		if(encodingString.length() == 1)
		{
			return;
		}
		
		payloadChar = encodingString.charAt(staticCharIdx++);
		addMsgTree(encodingString, this);
		
	}
	
	/*
	 * Method to print characters and their binary codes, wrapper for the outer classes print codes method
	 */
	public static void printCodes(MsgTree root, String code)
	{
		
		System.out.println("character    code\n-------------------------\n" + printCodeRecursive(root, ""));
		
	}
		
	
	
	/*
	 * Method for constructing the tree given a coding string
	 */
	private MsgTree addMsgTree(String message, MsgTree cur)
	{
		
		if(cur != null && cur.payloadChar != '^')
		{
			
			return cur;
		
		}
		else
		{
			
			if(message.length() <= staticCharIdx)
			{
				return null;
			}
			
			MsgTree leftLeaf = new MsgTree(message.charAt(staticCharIdx++));
			cur.left = addMsgTree(message, leftLeaf);
			
			if(message.length() <= staticCharIdx)
			{
				return null;
			}
			
			MsgTree rightLeaf = new MsgTree(message.charAt(staticCharIdx++));
			cur.right = addMsgTree(message, rightLeaf);
			return cur;
			
		}
		
	}
	
	/*
	 * Method for creating the output of what to print
	 */
	private static String printCodeRecursive(MsgTree cur, String s)
	{	
		if(cur.left == null && cur.right == null)
		{
			if(cur.payloadChar == '\n')
			{
				return "\\n" + "           " + s + "\n";
			}
			if(cur.payloadChar == ' ')
			{
				return "' '" + "          " + s + "\n";
			}
			
			return cur.payloadChar + "            " + s + "\n";
		}
		else
		{
			String output = "";
			String q = s;
			s = printCodeRecursive(cur.left, s + 0);
			output += s;
			if(cur.right != null)
			{
				s = printCodeRecursive(cur.right, q + 1);
				output += s;
			}
			
			return output;
			
		}
		
	}
	
	/*
	 * Creates the output from the binary code
	 */
	public String decode(MsgTree codes, String msg)
	{
		
		String output = "";
		
		while(binaryCount < msg.length())
		{
			output += decodeRecursive(codes, msg);
		}
		
		decodedMessage = output;
		
		return output;
		
	}
	
	/*
	 * Helper method for decode()
	 */
	private char decodeRecursive(MsgTree cur, String msg)
	{
		
		while(cur.left != null && cur.right != null)
		{
			if(msg.charAt(binaryCount) == '0')
			{
				cur = cur.left;
			}
			else
			{
				cur = cur.right;
			}
			
			binaryCount++;
			
		}
		
		return cur.payloadChar;
		
	}
	
	/*
	 * Finds the amount of bits of all the pathways
	 */
	private int bitCount(MsgTree cur, int curCount)
	{
		if(cur.payloadChar != '^')
		{
			return curCount;
		}
		else
		{
			
			int count = 0; 
			count += bitCount(cur.left, curCount + 1);
			count += bitCount(cur.right, curCount + 1);
			
			return count;
			
		}
	}
	
	/*
	 * Finds the amount of chars embedded into the tree
	 */
	private int charCount(MsgTree cur)
	{
		if(cur.payloadChar != '^')
		{
			return 1;
		}
		else
		{
			
			int count = 0; 
			count += charCount(cur.left);
			count += charCount(cur.right);
			
			return count;
			
		}
	}
	
	/*
	 * Calculates the states for the tree
	 */
	public String spaceSaving(MsgTree root, String code)
	{
		//Avg bit/char, go through decoded chars and add up all bits then divide by the number of chars
		
		String output = "";
		String decoded = "";
		
		//Making it so that you don't have to recalculate message
		if(!decoded.equals(decodedMessage) && !decoded.equals(""))
		{
			decoded = decode(null, code);
		}
		else
		{
			decoded = decodedMessage;
		}
		
		//Getting all chars from the decoded message
		Scanner stringScanner = new Scanner(decoded);
		int charCount = 0;
		
		while(stringScanner.hasNext())
		{
			String temp = stringScanner.next();
			charCount += temp.length();
		}
		
		stringScanner.close();
		
		//Gets the amount of chars embedded into the tree and gets the total of their bit paths
		int treeChars = charCount(root);
		int bitLength = bitCount(root, 0);
		double averageBitperChar = bitLength / treeChars;
		
		output = "STATISTICS:\n" + "Avg bits/char:           " + averageBitperChar +"\n";
		
		//Total chars, call decode add up all the characters in the output
		output += "Total characters:        " + charCount + "\n";
		
		//Finally take the total amount of compressed bits and divide it by all chars * 16 assuming they are uncompressed
		double percentSaved = Math.round((1 - (bitLength / (16.0 * treeChars))) * 100);
		output += "Space savings:           " + percentSaved + "%\n";
		
		return output;
		
	}
	
}
