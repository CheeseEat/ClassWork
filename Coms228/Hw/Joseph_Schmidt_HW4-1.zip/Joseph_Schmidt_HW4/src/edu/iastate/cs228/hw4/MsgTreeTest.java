package edu.iastate.cs228.hw4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/*
 * @author Joseph Schmidt
 * 
 * Com s 228 Batinov Hw4 4/18/2023
 * 
 */
public class MsgTreeTest {

	public static void main(String[] args) {
		
		boolean done = false;
		Scanner fileScanner = null;
		Scanner scan = new Scanner(System.in);
		
		while(!done)
		{
			scan = new Scanner(System.in);
			File file = new File(scan.next());
			try {
				fileScanner = new Scanner(file);
				done = true;
			} catch (FileNotFoundException e) {
				
				System.out.println("Invalid Name, Try Again");
				scan.nextLine();
				
			} 
		}
		
		String output = "";
		
		//Branch characters
		String encrpytion = "";
		
		while(fileScanner.hasNext())
		{
			if(encrpytion.equals(""))
			{
				encrpytion = output;
			}
			else {
				encrpytion += "\n";
				encrpytion += output;
			}	
			output = fileScanner.nextLine();
			if(output.charAt(0) == '1' || output.charAt(0) == '0')
			{
				break;
			}
		}
		
		//binary code
		String code = output;
		
		while(fileScanner.hasNext())
		{
			code += fileScanner.next();
		}
		
		MsgTree root = new MsgTree(encrpytion);
		root.printCodes(root, encrpytion);
		System.out.println(root.decode(root, code));
		System.out.println(root.spaceSaving(root, code));
		
	}

}
