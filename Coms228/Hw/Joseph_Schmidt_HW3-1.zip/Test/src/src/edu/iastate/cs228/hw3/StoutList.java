package src.edu.iastate.cs228.hw3;

import java.util.AbstractSequentialList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Implementation of the list interface based on linked nodes
 * that store multiple items per node.  Rules for adding and removing
 * elements ensure that each node (except possibly the last one)
 * is at least half full.
 * 
 * @author Joseph Schmidt
 * 
 * Com S 228 Data Structures HW3
 * 
 * Professor Batinov
 * 
 */
public class StoutList<E extends Comparable<? super E>> extends AbstractSequentialList<E>
{
  /**
   * Default number of elements that may be stored in each node.
   */
  private static final int DEFAULT_NODESIZE = 4;
  
  /**
   * Number of elements that can be stored in each node.
   */
  private final int nodeSize;
  
  /**
   * Dummy node for head.  It should be private but set to public here only  
   * for grading purpose.  In practice, you should always make the head of a 
   * linked list a private instance variable.  
   */
  public Node head;
  
  /**
   * Dummy node for tail.
   */
  private Node tail;
  
  /**
   * Number of elements in the list.
   */
  private int size;
  
  /**
   * Constructs an empty list with the default node size.
   */
  public StoutList()
  {
    this(DEFAULT_NODESIZE);
  }

  /**
   * Constructs an empty list with the given node size.
   * @param nodeSize number of elements that may be stored in each node, must be 
   *   an even number
   */
  public StoutList(int nodeSize)
  {
    if (nodeSize <= 0 || nodeSize % 2 != 0) throw new IllegalArgumentException();
    
    // dummy nodes
    head = new Node();
    tail = new Node();
    head.next = tail;
    tail.previous = head;
    this.nodeSize = nodeSize;
  }
  
  /**
   * Constructor for grading only.  Fully implemented. 
   * @param head
   * @param tail
   * @param nodeSize
   * @param size
   */
  public StoutList(Node head, Node tail, int nodeSize, int size)
  {
	  this.head = head; 
	  this.tail = tail; 
	  this.nodeSize = nodeSize; 
	  this.size = size; 
  }

  @Override
  public int size()
  {
	  return size;
  }
  
  /*
   * Adds given item to end of list. Will either end to current array if has room or creates new node if no space
   */
  @Override
  public boolean add(E item)
  {
	
	  if(item == null) throw new NullPointerException();
	  
	  Node curNode = findNodeAdd(size);
	  
	  if(curNode == tail)
	  {
		  
		  Node newNode = addNewNode(curNode.previous);
		  
		  newNode.addItem(item);
		  
	  }
	  else if(curNode.count < 4)
	  {
		  
		  curNode.addItem(item);
	  
	  }
	  else
	  {
		  
		  Node newNode = addNewNode(curNode);
		  
		  newNode.addItem(item);
		  
	  }
	  
	  size++;
	  
	  return true;
	  
  }
  
  /*
   * Add at given position. Will add item and shift elements as necessary. Will also increase the size.
   */
  @Override
  public void add(int pos, E item)
  {
	  
	  Node addNode = findNodeAdd(pos);
	  
	  addMore(addNode, pos, item);
	  
  }
  
  /*
   * Will remove at a given position. Will move items as necessary. Will decrease the size as well.
   */
  @Override
  public E remove(int pos)
  {
	  
	  Node currentNode = findNodeRemove(pos);
	  int offset = offsetFinderRemove(pos);
	  E data = null;
	  
	  //If list is empty
	  if(currentNode.count == 1)
	  {
		  data = currentNode.data[0];
		  unlink(currentNode);
	  }
	  //Just remove the item from the current node's array
	  else if(currentNode.next == tail && currentNode.count > nodeSize / 2 || currentNode.count > nodeSize / 2)
	  {
		  data = currentNode.data[offset];
		  currentNode.removeItem(offset);
	  }
	  //Have to do a merging operation
	  else
	  {
		  
		  Node nextNode = currentNode.next;
		  
		  //Half merge
		  if(nextNode.count > nodeSize / 2)
		  {
			  data = currentNode.data[offset];
			  currentNode.removeItem(offset);
			  E temp = nextNode.data[0];
			  currentNode.addItem(temp);
			  nextNode.removeItem(0);
		  }
		  //Full merge
		  else if(nextNode.count <= nodeSize / 2)
		  {
			  
			  data = currentNode.data[offset];
			  currentNode.removeItem(offset);
			  
			  while(nextNode.count > 0)
			  {
				  
				  E temp = nextNode.data[0];
				  nextNode.removeItem(0);
				  currentNode.addItem(temp);
				  
				  if(nextNode.count == 0)
				  {
					  unlink(nextNode);
				  }
				  
			  }
			  
			 
			  
		  }
	  }
	  
	  size--;
	  
    return data;
  }

  /**
   * Sort all elements in the stout list in the NON-DECREASING order. You may do the following. 
   * Traverse the list and copy its elements into an array, deleting every visited node along 
   * the way.  Then, sort the array by calling the insertionSort() method.  (Note that sorting 
   * efficiency is not a concern for this project.)  Finally, copy all elements from the array 
   * back to the stout list, creating new nodes for storage. After sorting, all nodes but 
   * (possibly) the last one must be full of elements.  
   *  
   * Comparator<E> must have been implemented for calling insertionSort().    
   */
  public void sort()
  {
	  
	  E[] arr = (E[]) new Comparable[size];
	  Iterator st = this.iterator();
	  int i = 0;
	  Comparator comp = new Comparator<E>()
	  {
		  
		  @Override
		  public int compare(E e1, E e2)
		  {
			  return e1.compareTo(e2);
		  }
		  
	  };
	  
	  while(st.hasNext())
	  {
		  arr[i++] = ((E) st.next());
	  }
	  
	  insertionSort(arr, comp);
	  
	  clear();
	  System.out.println(this.toStringInternal());

	  
	  ListIterator it = this.listIterator();
	  int j = 0;
	  
	  while(j < arr.length)
	  {
		  
		  this.add(arr[j++]);
		  System.out.println(this.toStringInternal());
		  
	  }
	  
  }
  
  /**
   * Sort all elements in the stout list in the NON-INCREASING order. Call the bubbleSort()
   * method.  After sorting, all but (possibly) the last nodes must be filled with elements.  
   *  
   * Comparable<? super E> must be implemented for calling bubbleSort(). 
   */
  public void sortReverse() 
  {
	  
	  E[] arr = (E[]) new Comparable[size];
	  Iterator st = this.iterator();
	  int i = 0;
	  
	  while(st.hasNext())
	  {
		  arr[i++] = ((E) st.next());
	  }
	  
	  bubbleSort(arr);
	  
	  clear();
	  System.out.println(this.toStringInternal());

	  
	  ListIterator it = this.listIterator();
	  int j = 0;
	  
	  while(j < arr.length)
	  {
		  
		  this.add(arr[j++]);
		  System.out.println(this.toStringInternal());
		  
	  }
	  
	  
  }
  
  /*
   * Method for clearing current list
   */
  public void clear()
  {
	  ListIterator it = this.listIterator();
	  int j = 0;
	  
	  while(it.hasNext())
	  {
		  it.next();
		  it.remove();
	  }
  }
  
  @Override
  public Iterator<E> iterator()
  {
    // TODO Auto-generated method stub
    //return new StoutIterator(head);
	  //return new StoutIterator();
	  return new StoutIterator();
  }

  @Override
  public ListIterator<E> listIterator()
  {
    // TODO Auto-generated method stub
    return new StoutListIterator();
  }

  @Override
  public ListIterator<E> listIterator(int index)
  {
    // TODO Auto-generated method stub
    return new StoutListIterator(index);
  }
  
  /**
   * Returns a string representation of this list showing
   * the internal structure of the nodes.
   */
  public String toStringInternal()
  {
    return toStringInternal(null);
  }

  /**
   * Returns a string representation of this list showing the internal
   * structure of the nodes and the position of the iterator.
   *
   * @param iter
   *            an iterator for this list
   */
  public String toStringInternal(ListIterator<E> iter) 
  {
      int count = 0;
      int position = -1;
      if (iter != null) {
          position = iter.nextIndex();
      }

      StringBuilder sb = new StringBuilder();
      sb.append('[');
      Node current = head.next;
      while (current != tail) {
          sb.append('(');
          E data = current.data[0];
          if (data == null) {
              sb.append("-");
          } else {
              if (position == count) {
                  sb.append("| ");
                  position = -1;
              }
              sb.append(data.toString());
              ++count;
          }

          for (int i = 1; i < nodeSize; ++i) {
             sb.append(", ");
              data = current.data[i];
              if (data == null) {
                  sb.append("-");
              } else {
                  if (position == count) {
                      sb.append("| ");
                      position = -1;
                  }
                  sb.append(data.toString());
                  ++count;

                  // iterator at end
                  if (position == size && count == size) {
                      sb.append(" |");
                      position = -1;
                  }
             }
          }
          sb.append(')');
          current = current.next;
          if (current != tail)
              sb.append(", ");
      }
      sb.append("]");
      return sb.toString();
  }


  /**
   * Node type for this list.  Each node holds a maximum
   * of nodeSize elements in an array.  Empty slots
   * are null.
   */
  private class Node
  {
    /**
     * Array of actual data elements.
     */
    // Unchecked warning unavoidable.
    public E[] data = (E[]) new Comparable[nodeSize];
    
    /**
     * Link to next node.
     */
    public Node next;
    
    /**
     * Link to previous node;
     */
    public Node previous;
    
    /**
     * Index of the next available offset in this node, also 
     * equal to the number of elements in this node.
     */
    public int count;

    /**
     * Adds an item to this node at the first available offset.
     * Precondition: count < nodeSize
     * @param item element to be added
     */
    void addItem(E item)
    {
      if (count >= nodeSize)
      {
        return;
      }
      data[count++] = item;
      //useful for debugging
      //      System.out.println("Added " + item.toString() + " at index " + count + " to node "  + Arrays.toString(data));
    }
  
    /**
     * Adds an item to this node at the indicated offset, shifting
     * elements to the right as necessary.
     * 
     * Precondition: count < nodeSize
     * @param offset array index at which to put the new element
     * @param item element to be added
     */
    void addItem(int offset, E item)
    {
      if (count >= nodeSize)
      {
    	  return;
      }
      for (int i = count - 1; i >= offset; --i)
      {
        data[i + 1] = data[i];
      }
      ++count;
      data[offset] = item;
      //useful for debugging 
//      System.out.println("Added " + item.toString() + " at index " + offset + " to node: "  + Arrays.toString(data));
    }

    /**
     * Deletes an element from this node at the indicated offset, 
     * shifting elements left as necessary.
     * Precondition: 0 <= offset < count
     * @param offset
     */
    void removeItem(int offset)
    {
      E item = data[offset];
      for (int i = offset + 1; i < nodeSize; ++i)
      {
        data[i - 1] = data[i];
      }
      data[count - 1] = null;
      --count;
    }    
  }
 
  private class StoutListIterator implements ListIterator<E>
  {	
	// constants you possibly use ...   
	  
	// instance variables ... 
	  public int index;
	  public Node currentNode;
	  public int offset;
	  int direction;
	  
	  
    /**
     * Default constructor 
     */
    public StoutListIterator()
    {
    	currentNode = findNodeAdd(0);
		offset = 0;
		index = 0;
    	direction = 0;
    }
    
    public StoutListIterator(int startIndex)
    {
		  
    	  index = startIndex;
		  currentNode = findNodeAdd(startIndex);
		  offset = offsetFinderAdd(startIndex);
		  direction  = 0;
    
    }
    
    public E get()
    {
    	Node currentNode = findNodeRemove(index);
    	int currentOffset = offsetFinderRemove(index);
    	
    	return currentNode.data[currentOffset];
    	
    }
    
    @Override
    public void remove()
    {
		
		if(direction < 0)
		{
			StoutList.this.remove(index - 1);
			index--;
		}
		else if (direction > 0)
		{
			StoutList.this.remove(index);
		}
		else
		{
			throw new IllegalStateException();
		}
		
		offset = offsetFinderRemove(index);
		currentNode = findNodeRemove(index);
		direction = 0;
    	
    }

	@Override
	public boolean hasPrevious() {
		
		if(offset == 0)
		{
			if(currentNode.previous == head)
			{
				return false;
			}
		}
		
		return true;
		
	}

	@Override
	public E previous() {
		
		if(!hasPrevious())
		{
			throw new NoSuchElementException();
		}	
		
		if(offset == 0)
		{
			currentNode = currentNode.previous;
			index--;
			offset = offsetFinderAdd(index);
		}
		else
		{
			offset--;
			index--;
		}
		
		E data = currentNode.data[offset];
		direction = 1;
		
		return data;
		
	}
	
	/*
	 * next index
	 */
	@Override
	public int nextIndex() {
		
		return index;
		
	}
	
	/*
	 * previous index.
	 */
	@Override
	public int previousIndex() 
	{
		
		return index - 1;
		
	}
	
	/*
	 * If the iterator has a next item to go to.
	 */
	@Override
	public boolean hasNext() {
		
		if(currentNode == tail)
		{
			return false;
		}
		
		if(offset >= currentNode.count || offset == nodeSize)
		{
			if(currentNode.next == tail)
			{
				return false;
			}
		}
		
		return true;
		
	}

	/*
	 * Goes to the next item in the list and returns the item there.
	 */
	@Override
	public E next() {
		
		if(!hasNext())
		{
			throw new NoSuchElementException();
		}
		
		if(offset == nodeSize || offset == currentNode.count)
		{
			currentNode = currentNode.next;
			offset = 0;
		}
		
		E data = currentNode.data[offset];
		
		offset++;
		
		index++;
		direction = -1;
		return data;
	
	}
	
	/*
	 * Sets the last item travled across to the given item.
	 */
	@Override
	public void set(E e) {
		
		Node setNode;
		int setPos;
		
		if(direction == 0)
		{
			throw new IllegalStateException();
		}
		else if(direction == -1)
		{
			
			//Using remove here to find the first real item
			setNode = findNodeRemove(index - 1);
			setPos = offsetFinderRemove(index - 1);	
			setNode.data[setPos] = e;
			
		}
		else if(direction == 1)
		{
			
			//Using remove here to find the first real item
			setNode = findNodeRemove(index);
			setPos = offsetFinderRemove(index);		
			setNode.data[setPos] = e;
				
		}
		
		
	}
	
	/*
	 * Adds item.
	 */
	@Override
	public void add(E e) {
		
		StoutList.this.add(index, e);
		index++;
		offset = offsetFinderRemove(index);
		currentNode = findNodeRemove(index);
		direction = 0;
		
	}
    
    // Other methods you may want to add or override that could possibly facilitate 
    // other operations, for instance, addition, access to the previous element, etc.
    // 
    // ...
    // 
  }
  
  private class StoutIterator implements Iterator<E>
  {
	  
	  public int index;
	  public Node currentNode;
	  public int offset;
	  
	  public StoutIterator()
	  {
		  currentNode = findNodeRemove(0);
		  offset = 0;
		  index = 0;
	  }
	  
	  public StoutIterator(int pos)
	  {
		  currentNode = findNodeAdd(pos);
		  offset = offsetFinderAdd(pos);
		  index = pos;
	  }
	  
	  /*
	   * If the iterator has a next item to go to.
	   */
	@Override
	public boolean hasNext() {
		
		if(currentNode == tail)
		{
			return false;
		}
		
		if(offset >= currentNode.count || offset == nodeSize)
		{
			if(currentNode.next == tail)
			{
				return false;
			}
		}
		
		return true;
		
	}
	
	@Override
	public E next() {
		
		if(!hasNext())
		{
			throw new NoSuchElementException();	
		}
		
		if(offset == nodeSize || offset == currentNode.count)
		{
			currentNode = currentNode.next;
			offset = 0;
		}
		
		E data = currentNode.data[offset];
		index++;
		
		offset++;
		
		return data;
			
	}
	  
  }
  
  private void unlink(Node current)
  {
	  
	  current.next.previous = current.previous;
	  current.previous.next = current.next;
	  
  }
  
  /*
   * Adds a new node in front of current.
   */
  private Node addNewNode(Node current)
  {
	  
	  Node newNode = new Node();
	  
	  newNode.previous = current;
	  newNode.next = current.next;
	  current.next.previous = newNode;
	  current.next = newNode;
	  
	  return newNode;
	  
  }
  
  /*
   * Finds the node for the given index. Add version finds the node and takes into account that if the index is the 
   * last item in the array this is the array you want to be at.
   */
  private Node findNodeAdd(int pos)
  {
	    
	  Node currentNode;
	  currentNode = head.next;
	  
	  if(currentNode == tail)
	  {
		  return tail;
	  }
	  
	  int counter = currentNode.count;
	  boolean done = false;
	  
	  while(!done)
	  {

		  
		  if((counter - 1) >= pos)
		  {
			  done = true;
		  }
		  else if((pos - (counter - 1)) == 1 && currentNode.count < nodeSize)
		  {
			  done = true;
		  }
		  else
		  {
			  currentNode = currentNode.next;
			  counter += currentNode.count;
		  }
		  
	  }
	  
	  return currentNode;
	  
  }
  
  /*
   * Finds a node at the given index. Remove version finds the node with the given index in it. This differs from
   * the add version where the add version will stop at the node behind it if the index position is the last
   * position in the array. This version stops at the node that actually has an item at the given index.
   */
  private Node findNodeRemove(int pos)
  {
	    
	  Node currentNode;
	  currentNode = head.next;
	  
	  if(currentNode == tail)
	  {
		  return tail;
	  }
	  
	  int counter = currentNode.count;
	  boolean done = false;
	  
	  while(!done)
	  {

		  
		  if((counter - 1) >= pos)
		  {

			  done = true;
		  }
		  else
		  {
			  currentNode = currentNode.next;
			  counter += currentNode.count;
		  }
		  
	  }
	  
	  return currentNode;
	  
  }
  
  /*
   * Finds the offset for the given index. Add version finds the offset and takes into account that if the index is the 
   * last item in the array this is the array you want to be at.
   */
  private int offsetFinderAdd(int pos)
  {
	  

	  Node currentNode;
	  currentNode = head.next;
	  
	  if(currentNode == tail)
	  {
		  return 0;
	  }
	  
	  int counter = currentNode.count;
	  int prevCounter = 0;
	  boolean done = false;
	  int offset = 0;
	  
	  while(!done)
	  {

		  
		  if((counter - 1) >= pos)
		  {
			  done = true;
		  }
		  else if((pos - (counter - 1)) == 1 && currentNode.count < nodeSize)
		  {
			  done = true;
		  }
		  else
		  {
			  prevCounter = counter;
			  currentNode = currentNode.next;
			  counter += currentNode.count;
		  }
		  
	  }

	  return pos - prevCounter;
	  
  }
  
  /*
   * Finds a node at the given index. Remove version finds the node with the given index in it. This differs from
   * the add version where the add version will stop at the node behind it if the index position is the last
   * position in the array. This version stops at the node that actually has an item at the given index.
   */
  private int offsetFinderRemove(int pos)
  {
	  

	  Node currentNode;
	  currentNode = head.next;
	  
	  if(currentNode == tail)
	  {
		  return 0;
	  }
	  
	  int counter = currentNode.count;
	  int prevCounter = 0;
	  boolean done = false;
	  int offset = 0;
	  
	  while(!done)
	  {

		  
		  if((counter - 1) >= pos)
		  {
			  done = true;
		  }
		  else
		  {
			  prevCounter = counter;
			  currentNode = currentNode.next;
			  counter += currentNode.count;
		  }
		  
	  }
	  
	  return pos - prevCounter;
	  
  }
  
  
  private class NodeInfo
  {
	  
	  public Node node;
	  public int offset;
	  
	  public NodeInfo(Node node, int offset)
	  {
		  this.node = node;
		  this.offset = offset;
	  }
	  
  }
  
  /*
   * Logic for add method at a given index.
   */
  private NodeInfo addMore(Node n, int index, E item)
  {
	  
	  int offset = offsetFinderAdd(index);
	  
	  Node whereAddedNode = n;
	  int whereAddedOffset = offset;
	  
	  if(size == 0)
	  {
		  Node newNode = addNewNode(head);
		  newNode.addItem(item);
		  whereAddedNode = newNode;
	  }
	  else if(offset == 0 & ((n.previous != head) && (n.previous.count < nodeSize) || (n == tail) && (n.previous.count == nodeSize)))
	  {
		  
		  if((n.previous != head) && (n.previous.count < nodeSize))
		  {
			  n.previous.addItem(offset, item);
		  }
		  
		  if((n == tail) && (n.previous.count == nodeSize))
		  {
			  
			  Node newNode = addNewNode(n.previous);
			  newNode.addItem(item);
			  
			  whereAddedNode = newNode;
			  
		  }
		  
	  }
	  else if(n.count < nodeSize)
	  {
		  
		  n.addItem(offset, item);
		  
	  }
	  else
	  {
		  
		  if(offset <= (nodeSize / 2))
		  {
			  whereAddedNode = nodeAddMiddle(n);
			  offset = offsetFinderAdd(index);
			  n.addItem(offset, item);
		  }
		  
		  if(offset > (nodeSize / 2))
		  {
			  Node newNode = nodeAddMiddle(n);
			  offset = offsetFinderAdd(index);
			  newNode.addItem((offset - newNode.count/2), item);
			  whereAddedNode = newNode;
			  whereAddedOffset = offset - newNode.count/2;
		  }
		  
	  }
	  
	  size++;
	  
	  return new NodeInfo(whereAddedNode, whereAddedOffset);
	  
  }
  
  /*
   * Method for creating a new node and adding in value from the end of the list. Used when adding to a certain
   * index and the array become full and have to transfer over some of the items to a new array.
   */
  private Node nodeAddMiddle(Node previous)
  {
	  
	  int floor = nodeSize / 2;
	  if(floor%2==0) floor--;
	  int topHalfIndex = previous.count - 1;
	  
	  Node newNode = addNewNode(previous);
	  
	  while(floor < topHalfIndex)
	  {
		  newNode.addItem(0, previous.data[topHalfIndex]);
		  previous.data[topHalfIndex] = null;
		  previous.count--;
		  topHalfIndex--;
	  }
	  
	  return newNode;
	  
  }

  /**
   * Sort an array arr[] using the insertion sort algorithm in the NON-DECREASING order. 
   * @param arr   array storing elements from the list 
   * @param comp  comparator used in sorting 
   */
  private void insertionSort(E[] arr, Comparator<? super E> comp)
  {
	  
	  int numSize = arr.length;
		int i = 0;
		int j = 0;
		E temp;
		
		for(i = 1; i < numSize; i++)
		{
			
			j = i;
			
			while(j > 0 && comp.compare(arr[j - 1], arr[j]) > 0)
			{
				temp = arr[j - 1];
				arr[j - 1] = arr[j];
				arr[j] = temp;
				j--;
			}
			
		}
		 
	 
  }
  
  /**
   * Sort arr[] using the bubble sort algorithm in the NON-INCREASING order. For a 
   * description of bubble sort please refer to Section 6.1 in the project description. 
   * You must use the compareTo() method from an implementation of the Comparable 
   * interface by the class E or ? super E. 
   * @param arr  array holding elements from the list
   */
  private void bubbleSort(E[] arr)
  {
	  int n = arr.length;
      for (int i = 0; i < n - 1; i++)
          for (int j = 0; j < n - i - 1; j++)
              if (arr[j].compareTo(arr[j + 1]) < 0) {
                  // swap arr[j+1] and arr[j]
                  E temp = arr[j];
                  arr[j] = arr[j + 1];
                  arr[j + 1] = temp;
              }
  }
 

}