package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 *  
 * @author Joseph Schmidt
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if needed
	
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		
		super(pts);
		algorithm = "Merge Sort    ";
		
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 */
	@Override 
	public void sort()
	{
		
		mergeSortRec(points, 0, points.length - 1);
		
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts, int first, int last)
	{
		
		int mid = 0;
		
		if(first < last)
		{
			
			mid = (first + last) / 2;
			
			mergeSortRec(pts, first, mid);
			mergeSortRec(pts, mid + 1, last);
			
			merge(first, mid, last);
			
		}
		
	}

	
	// Other private methods if needed ...
	
	private void merge(int i, int j, int k)
	{
		
		int leftPos = i;
		int rightPos = j + 1;
		int mergePos = 0;
		int size = k - i  + 1;
		Point[] mergedPoints = new Point[size];
		
		while(leftPos <= j && rightPos <= k)
		{
			
			if(0 >= pointComparator.compare(points[leftPos], points[rightPos]))
			{
				mergedPoints[mergePos] = points[leftPos];
				leftPos++;
			}
			else
			{
				mergedPoints[mergePos] = points[rightPos];
				rightPos++;
			}
			
			mergePos++;
			
		}
		
		while(leftPos <= j)
		{
			mergedPoints[mergePos] = points[leftPos];
			leftPos++;
			mergePos++;
		}
		
		while(rightPos <= k)
		{
			mergedPoints[mergePos] = points[rightPos];
			rightPos++;
			mergePos++;
		}
		
		for(mergePos = 0; mergePos < size; mergePos++)
		{
			points[mergePos + i] = mergedPoints[mergePos];
		}
	}
	
}
