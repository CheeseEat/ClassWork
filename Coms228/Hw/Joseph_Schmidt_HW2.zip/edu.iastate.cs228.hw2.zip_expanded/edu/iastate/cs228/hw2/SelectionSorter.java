package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;


/**
 *  
 * @author Joseph Schmidt
 *
 */

/**
 * 
 * This class implements selection sort.   
 *
 */

public class SelectionSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/**
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts  
	 */
	public SelectionSorter(Point[] pts)  
	{
		super(pts);
		algorithm = "Selection Sort";
	}	

	
	/** 
	 * Apply selection sort on the array points[] of the parent class AbstractSorter.  
	 * 
	 */
	@Override 
	public void sort()
	{
		
		int i = 0;
		int j = 0;
		int lowIndex = 0;
		int pointsSize = points.length;
		
		for(i = 0; i < pointsSize - 1; i++)
		{
			
			lowIndex = i;
			
			for(j = i + 1; j < pointsSize; j++)
			{
				//if(points[j].compareTo(points[lowIndex]) < 0)
				if(pointComparator.compare(points[j], points[lowIndex]) < 0)
				{
					lowIndex = j;
				}
			}
			
			swap(i, lowIndex);
			
		}
		
	}	
}
