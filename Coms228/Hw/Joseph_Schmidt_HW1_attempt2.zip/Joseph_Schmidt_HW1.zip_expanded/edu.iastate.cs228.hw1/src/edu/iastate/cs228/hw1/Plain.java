package edu.iastate.cs228.hw1;

/**
 *  
 * @author Joseph Schmidt
 *
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner; 
import java.util.Random; 

/**
 * 
 * The plain is represented as a square grid of size width x width. 
 *
 */
public class Plain 
{
	private int width; // grid size: width X width 
	
	public Living[][] grid; 
	
	/**
	 *  Default constructor reads from a file 
	 */
	public Plain(String inputFileName) throws FileNotFoundException
	{		
        // TODO 
		// 
		// Assumption: The input file is in correct format. 
		// 
		// You may create the grid plain in the following steps: 
		// 
		// 1) Reads the first line to determine the width of the grid.
		// 
		// 2) Creates a grid object. 
		// 
		// 3) Fills in the grid according to the input file. 
		// 
		// Be sure to close the input file when you are done. 
		
		
		FileInputStream fileInStream;
		Scanner fileScanner;
		Scanner lineScanner;
		Scanner titleScanner;
		width = 0;
		
		File file = new File(inputFileName);
		
		fileScanner = new Scanner(file);
		
		String currentLine = fileScanner.nextLine();
		lineScanner = new Scanner(currentLine);
		
		while(lineScanner.hasNext())
		{
			lineScanner.next();
			width++;
		}
		
		grid = new Living[width][width];
		
		for(int row = 0; row < width; row++)
		{
			
			lineScanner = new Scanner(currentLine);
			
			for(int col = 0; col < width; col++)
			{
				
				String token = lineScanner.next();
				Living currentLiving;
				char currentChar = token.charAt(0);
				
				if(currentChar == 'E')
				{
					currentLiving = new Empty(this, row, col);
				}
				else if(currentChar == 'G')
				{
					currentLiving = new Grass(this, row, col);
				}
				else
				{
					
					char charAge = token.charAt(1);
					int age = Character.getNumericValue(charAge);
					
					if(currentChar == 'R')
					{
						currentLiving = new Rabbit(this, row, col, age);
					}
					else if(currentChar == 'B')
					{
						currentLiving = new Badger(this, row, col, age);
					}
					else //(currentChar == 'F')
					{
						currentLiving = new Fox(this, row, col, age);
					}
				}
				
				grid[row][col] = currentLiving;
				
			}
			
			if(row != width - 1) currentLine = fileScanner.nextLine();
			
		}
		
		fileScanner.close();
		lineScanner.close();
		
	}
	
	/**
	 * Constructor that builds a w x w grid without initializing it. 
	 * @param width  the grid 
	 */
	public Plain(int w)
	{
		
		width = w;
		grid = new Living[width][width];
		
	}
	
	
	public int getWidth()
	{
		// TODO  
		return width;  // to be modified 
	}
	
	/**
	 * Initialize the plain by randomly assigning to every square of the grid  
	 * one of BADGER, FOX, RABBIT, GRASS, or EMPTY.  
	 * 
	 * Every animal starts at age 0.
	 */
	public void randomInit()
	{
		
		Random generator = new Random(); 
		
		 
		// TODO 
		
			
		for(int row = 0; row < width; row++) {
			
			for(int col = 0; col < width; col++)
			{
				
				int num = generator.nextInt(5);
		
				switch(num)
				{
				
					case 0:
						grid[row][col] = new Badger(this, row, col, 0);
						break;
					
					case 1:
						grid[row][col] = new Empty(this, row, col);
						break;
						
					case 2:
						grid[row][col] = new Fox(this, row, col, 0);
						break;
						
					case 3: 
						grid[row][col] = new Grass(this, row, col);
						break;
						
					case 4:
						grid[row][col] = new Rabbit(this, row, col, 0);
						break;
						
				}
			
			}
		
		}
		
	}
	
	
	/**
	 * Output the plain grid. For each square, output the first letter of the living form
	 * occupying the square. If the living form is an animal, then output the age of the animal 
	 * followed by a blank space; otherwise, output two blanks.  
	 */
	public String toString()
	{
		
		String output = "";
		
		for(int row = 0; row < width; row++)
		{
			for(int col = 0; col < width; col++)
			{
				
				Living curLiving = grid[row][col];
				
				output += curLiving.returnSymbol() + " ";
				
			}
			
			output += "\n";
			
		}
		
		return output;
		
	}
	

	/**
	 * Write the plain grid to an output file.  Also useful for saving a randomly 
	 * generated plain for debugging purpose. 
	 * @throws FileNotFoundException, IOException
	 */
	public void write(String outputFileName) throws FileNotFoundException, IOException
	{
		// TODO 
		// 
		// 1. Open the file. 
		// 
		// 2. Write to the file. The five life forms are represented by characters 
		//    B, E, F, G, R. Leave one blank space in between. Examples are given in
		//    the project description. 
		// 
		// 3. Close the file. 
		
		FileWriter fileWriter;
			
		File file = new File(outputFileName);
		fileWriter = new FileWriter(file);
		fileWriter.write(this.toString());
		
		fileWriter.close();
			

		
		
	}			
}
