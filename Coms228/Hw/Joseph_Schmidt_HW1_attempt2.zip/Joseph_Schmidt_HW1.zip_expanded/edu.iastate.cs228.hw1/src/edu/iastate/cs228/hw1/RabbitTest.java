package edu.iastate.cs228.hw1;
import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 
import static org.junit.Assert.assertTrue; 
import static org.junit.Assert.assertFalse; 
import static org.junit.Assert.assertEquals; 
import static org.junit.Assert.fail; 


/*
 * @author Joseph Schmidt
 */
public class RabbitTest {
	
	Wildlife w;
	Plain p;
	
	Rabbit cornerRabbit;
	Rabbit middleRabbit;
	
	@Before
	public void setUp()
	{
			
		p = new Plain(3);
		
//		p.grid = 
//		{
//			{new Rabbit(p, 0, 0, 0), new Rabbit(p, 0, 1, 0), new Grass(p, 0, 2)},
//			{new Badger(p, 1, 0, 0), new Rabbit(p, 1, 1, 0), new Grass(p, 1, 2)},
//			{new Fox(p, 2, 0, 0), new Grass(p, 2, 1), new Empty(p, 2, 2)}
//		};
		
		cornerRabbit = new Rabbit(p, 0, 0, 0);
		middleRabbit = new Rabbit(p, 1, 1, 0);
		
		p.grid[0][0] = cornerRabbit;
		p.grid[0][1] = new Rabbit(p, 0, 1, 0);
		p.grid[0][2] = new Grass(p, 0, 2);
	    p.grid[1][0] = new Badger(p, 1, 0, 0);
		p.grid[1][1] = middleRabbit;
		p.grid[1][2] = new Grass(p, 1, 2);
		p.grid[2][0] = new Fox(p, 2, 0, 0);
	    p.grid[2][1] = new Grass(p, 2, 1);
	    p.grid[2][2] = new Empty(p, 2, 2);
		
				
				
	}
	
	@Test
	public void constructorTest()
	{
		Rabbit testRabbit = new Rabbit(p, 1, 1, 0);
		assertEquals("checking plain", p, testRabbit.plain);
		assertEquals("checking row & column", true, testRabbit.row == 1 && testRabbit.column == 1);
		assertEquals("Checking age", 0, testRabbit.age);
	}
	
	@Test 
	public void whoTest()
	{
		Rabbit testRabbit = new Rabbit(p, 1, 1, 0);
		assertEquals("Checking who, should return RABBIT", State.RABBIT, testRabbit.who());
	}
	
	@Test
	public void updatePlainBadgerAge()
	{
		
		//Checking that at age 3, after the next updatePlain call it's location is replaced with an EMPTY
		p.grid[1][1] = new Rabbit(p, 1, 1, 3);
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleRabbit = pNew.grid[1][1];
		
		assertEquals("Should be Empty", State.EMPTY, newMiddleRabbit.who());	
		
	}
	
	@Test
	public void updatePlainNoGrass()
	{
		//Getting rid of all grass, middleRabbit should be EMPTY after updatePlain is called
		p.grid[0][2] = new Rabbit(p, 1, 1, 0);
		p.grid[1][2] = new Rabbit(p, 1, 2, 0);
		p.grid[2][1] = new Rabbit(p, 2, 1, 0);
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleRabbit = pNew.grid[1][1];
		
		assertEquals("Should be Empty", State.EMPTY, newMiddleRabbit.who());	
	}
	
	@Test
	public void updatePlainMoreFoxesBadgersThanRabbits()
	{
		
		//Checking to see if at least as many foxes and badgers in neighborhood than rabbits should be Fox
		//The plain is already set up to match this test case
		
		//Making Badgers and Foxes numbers even with Rabbit should return Fox 
		p.grid[2][1] = new Fox(p, 2, 1, 0);
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleRabbit = pNew.grid[1][1];
		
		assertEquals("Should be Fox", State.FOX, newMiddleRabbit.who());	
		
	}
	
	@Test
	public void updatePlainMoreBadgersThanFoxes()
	{
		
		//Checking to see if there are more badgers than there are Rabbits than should be badger
		p.grid[0][0] = new Badger(p, 0, 0, 0);
		p.grid[0][1] = new Badger(p, 0, 1, 0);
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleRabbit = pNew.grid[1][1];
		
		assertEquals("Should be Badger", State.BADGER, newMiddleRabbit.who());	
		
	}
	
	@Test
	public void updatePlainFoxLiveOn()
	{
		
		//The Rabbit should live on and age should increase
		//The plain is already set up to match this test case
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleRabbit = pNew.grid[1][1];
		Rabbit newMiddleEmptyRabbit = (Rabbit) newMiddleRabbit;
		
		assertEquals("Should be Fox", State.RABBIT, newMiddleRabbit.who());	
		assertEquals("Should be age 1", 1, newMiddleEmptyRabbit.age);
		
	}
	
}
