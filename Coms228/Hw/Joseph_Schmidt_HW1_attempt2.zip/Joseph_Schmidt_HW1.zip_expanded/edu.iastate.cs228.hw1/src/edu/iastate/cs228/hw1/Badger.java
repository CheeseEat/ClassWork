package edu.iastate.cs228.hw1;

/**
 *  
 * @author Joseph Schmidt
 *
 */

/**
 * A badger eats a rabbit and competes against a fox. 
 */
public class Badger extends Animal
{
	/**
	 * Constructor 
	 * @param p: plain
	 * @param r: row position 
	 * @param c: column position
	 * @param a: age 
	 */
	public Badger (Plain p, int r, int c, int a) 
	{
		super(p, r, c, a);
	}
	
	/**
	 * A badger occupies the square. 	 
	 */
	public State who()
	{
		return State.BADGER; 
	}
	
	/**
	 * A badger dies of old age or hunger, or from isolation and attack by a group of foxes. 
	 * @param pNew     plain of the next cycle
	 * @return Living  life form occupying the square in the next cycle. 
	 */
	public Living next(Plain pNew)
	{
		// TODO 
		// 
		// See Living.java for an outline of the function. 
		// See the project description for the survival rules for a badger. 
		
		super.census(livings);
		int badgers = livings[0];
		int empties = livings[1];
		int foxes = livings[2];
		int grasses = livings[3];
		int rabbits = livings[4];
		
		Living nextLiving;
		
		if(super.age >= 4)
		{
			nextLiving = new Empty(pNew, super.row, super.column);
		}
		else if(badgers == 1 && foxes > 1)
		{
			nextLiving = new Fox(pNew, super.row, super.column, 0);
		}
		else if((badgers + foxes) > rabbits)
		{
			nextLiving = new Empty(pNew, super.row, super.column);
		}
		else
		{
			nextLiving = new Badger(pNew, super.row, super.column, age + 1);
		}
		
		return nextLiving; 
		
	}
	
	@Override
	public String returnSymbol()
	{
		return "B" + age;
	}
	
}
