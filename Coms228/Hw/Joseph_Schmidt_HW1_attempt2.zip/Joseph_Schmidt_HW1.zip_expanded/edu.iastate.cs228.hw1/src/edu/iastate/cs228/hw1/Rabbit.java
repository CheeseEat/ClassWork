package edu.iastate.cs228.hw1;

/**
 *  
 * @author Joseph Schmidt
 *
 */

/*
 * A rabbit eats grass and lives no more than three years.
 */
public class Rabbit extends Animal 
{	
	/**
	 * Creates a Rabbit object.
	 * @param p: plain  
	 * @param r: row position 
	 * @param c: column position
	 * @param a: age 
	 */
	public Rabbit (Plain p, int r, int c, int a) 
	{
		super(p, r, c, a);
	}
		
	// Rabbit occupies the square.
	public State who()
	{
		// TODO  
		return State.RABBIT; 
	}
	
	/**
	 * A rabbit dies of old age or hunger. It may also be eaten by a badger or a fox.  
	 * @param pNew     plain of the next cycle 
	 * @return Living  new life form occupying the same square
	 */
	public Living next(Plain pNew)
	{
		// TODO 
		// 
		// See Living.java for an outline of the function. 
		// See the project description for the survival rules for a rabbit. 
		
		super.census(livings);
		int badgers = livings[0];
		int empties = livings[1];
		int foxes = livings[2];
		int grasses = livings[3];
		int rabbits = livings[4];
		
		Living nextLiving;
		
		if(super.age >= 3)
		{
			nextLiving = new Empty(pNew, super.row, super.column);
		}
		else if(grasses == 0)
		{
			nextLiving = new Empty(pNew, super.row, super.column);
		}
		else if((foxes + badgers) >= rabbits && (foxes > badgers))
		{
			nextLiving = new Fox(pNew, super.row, super.column, 0);
		}
		else if(badgers > rabbits)
		{
			nextLiving = new Badger(pNew, super.row, super.column, 0);
		}
		else
		{
			nextLiving = new Rabbit(pNew, super.row, super.column, age + 1);
		}
		
		return nextLiving; 
		
	}
	
	@Override
	public String returnSymbol()
	{
		return "R" + age;
	}
	
}
