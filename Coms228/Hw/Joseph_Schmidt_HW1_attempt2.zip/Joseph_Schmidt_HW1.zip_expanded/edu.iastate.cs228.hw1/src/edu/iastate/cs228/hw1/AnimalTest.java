package edu.iastate.cs228.hw1;
import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 
import static org.junit.Assert.assertTrue; 
import static org.junit.Assert.assertFalse; 
import static org.junit.Assert.assertEquals; 
import static org.junit.Assert.fail; 

/*
 * 
 * @author Joseph Schmidt
 * 
 */

public class AnimalTest {
	
	Wildlife w;
	Plain p;
	
	Badger cornerBadger;
	Badger middleBadger;
	
	@Before
	public void setUp()
	{
			
		p = new Plain(3);
		
//		p.grid = 
//		{
//			{new Badger(p, 0, 0, 0), new Rabbit(p, 0, 1, 0), new Grass(p, 0, 2)},
//			{new Badger(p, 1, 0, 0), new Badger(p, 1, 1, 0), new Grass(p, 1, 2)},
//			{new Fox(p, 2, 0, 0), new Grass(p, 2, 1), new Empty(p, 2, 2)}
//		};
		
		cornerBadger = new Badger(p, 0, 0, 0);
		middleBadger = new Badger(p, 1, 1, 0);
		
		p.grid[0][0] = cornerBadger;
		p.grid[0][1] = new Rabbit(p, 0, 1, 0);
		p.grid[0][2] = new Grass(p, 0, 2);
	    p.grid[1][0] = new Badger(p, 1, 0, 0);
		p.grid[1][1] = middleBadger;
		p.grid[1][2] = new Grass(p, 1, 2);
		p.grid[2][0] = new Fox(p, 2, 0, 0);
	    p.grid[2][1] = new Grass(p, 2, 1);
	    p.grid[2][2] = new Empty(p, 2, 2);
		
				
				
	}
	
	@Test
	public void constructorTest()
	{
		Badger testBadger = new Badger(p, 1, 1, 0);
		assertEquals("checking plain", p, testBadger.plain);
		assertEquals("checking row & column", true, testBadger.row == 1 && testBadger.column == 1);
		assertEquals("Checking age", 0, testBadger.age);
	}
	
	@Test 
	public void myAgeTest()
	{
		Badger testBadger = new Badger(p, 1, 1, 0);
		assertEquals("Checking myAge, should return 0", 0, testBadger.myAge());
	}
	
}
