package edu.iastate.cs228.hw1;

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 
import static org.junit.Assert.assertTrue; 
import static org.junit.Assert.assertFalse; 
import static org.junit.Assert.assertEquals; 
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner; 

/*
 * @author Joseph Schmidt
 */
public class PlainTest {
	
	Wildlife w;
	Plain p;
	
	@Before
	public void setUp()
	{
			
		p = new Plain(3);
		
//		p.grid = 
//		{
//			{new Empty(p, 0, 0), new Rabbit(p, 0, 1, 0), new Grass(p, 0, 2)},
//			{new Badger(p, 1, 0, 0), new Empty(p, 1, 1), new Grass(p, 1, 2)},
//			{new Fox(p, 2, 0, 0), new Grass(p, 2, 1), new Badger(p, 2, 2, 0)}
//		};
		
		p.grid[0][0] = new Empty(p, 0, 0);
		p.grid[0][1] = new Rabbit(p, 0, 1, 0);
		p.grid[0][2] = new Grass(p, 0, 2);
	    p.grid[1][0] = new Badger(p, 1, 0, 0);
		p.grid[1][1] = new Empty(p, 1, 1);
		p.grid[1][2] = new Grass(p, 1, 2);
		p.grid[2][0] = new Fox(p, 2, 0, 0);
	    p.grid[2][1] = new Grass(p, 2, 1);
	    p.grid[2][2] = new Badger(p, 2, 2, 0);
				
	}
	
	@Test
	public void testgetWidth()
	{
		
		//Should be testing that width is correct and getWidth() method work correctly
		
		assertEquals("Should return 3", 3, p.getWidth());
		
	}
	
	@Test
	public void testRandomInit()
	{
		
		p = new Plain(3);
		Plain p2 = new Plain(3);
		
		p.randomInit();
		
		assertEquals(true, p.grid[0][0] != null);
		assertEquals(true, p.grid[0][1] != null);
		assertEquals(true, p.grid[0][2] != null);
		assertEquals(true, p.grid[1][0] != null);
		assertEquals(true, p.grid[1][1] != null);
		assertEquals(true, p.grid[1][2] != null);
		assertEquals(true, p.grid[2][0] != null);
		assertEquals(true, p.grid[2][1] != null);
		assertEquals(true, p.grid[2][2] != null);
		
		boolean check = false;
		
		if( p.grid[0][0].who() != p.grid[0][1].who() ||
		    p.grid[0][0].who() != p.grid[0][2].who() ||
			p.grid[0][0].who() != p.grid[1][0].who() ||
			p.grid[0][0].who() != p.grid[1][1].who() ||
		    p.grid[0][0].who() != p.grid[1][2].who() || 
			p.grid[0][0].who() != p.grid[2][0].who() ||
			p.grid[0][0].who() != p.grid[2][1].who() ||
			p.grid[0][0].who() != p.grid[2][2].who())
		{
			check = true;
		}
		  
		assertEquals("Checking to see if atleast one cell differentiates between the others to check for some sort of randomness", true, check);
	
	}
	
	@Test
	public void toStringTest()
	{
		
		Plain testPlain = new Plain(2);
		testPlain.grid[0][0] = new Empty(testPlain, 0, 0);
		testPlain.grid[0][1] = new Rabbit(testPlain, 0, 1, 2);
		testPlain.grid[1][0] = new Badger(testPlain, 1, 0, 0);
		testPlain.grid[1][1] = new Grass(testPlain, 1, 1);
		
		String testOutput = "E  R2 \nB0 G  \n";
		
		assertEquals("Testing toString method", true, testPlain.toString().equals(testOutput));
		
	}
	
	@Test
	public void plainFileConstructor()
	{
		
		Plain tester = null;
		
		try
		{
			
			tester = new Plain("public1-3x3.txt");
			
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Invalid File Name");
		}
		
		assertEquals("Should be Grass", State.GRASS, tester.grid[0][0].who()); 
		assertEquals("Should be Badger", State.BADGER, tester.grid[0][1].who()); 
		assertEquals("Should be Fox", State.FOX, tester.grid[0][2].who()); 
		assertEquals("Should be Fox", State.FOX, tester.grid[1][0].who()); 
		assertEquals("Should be Fox", State.FOX, tester.grid[1][1].who()); 
		assertEquals("Should be Rabbit", State.RABBIT, tester.grid[1][2].who()); 
		assertEquals("Should be Fox", State.FOX, tester.grid[2][0].who()); 
		assertEquals("Should be Empty", State.EMPTY, tester.grid[2][1].who()); 
		assertEquals("Should be Grass", State.GRASS, tester.grid[2][2].who()); 
		
	}
	
	@Test(expected = FileNotFoundException.class)
	public void wrongFileInput() throws FileNotFoundException
	{
		
		Plain testPlain = new Plain("BigChungus.txt");
		
	}
	
	@Test
	public void writeTest()
	{
		
		File output = new File("OutputFile.txt");
		Scanner scan = null;
		
		try 
		{
			p.write("OutputFile.txt");
			scan = new Scanner(output);
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Invalid File Name");
		}
		catch(IOException f)
		{
			System.out.println("Could Not Open File");
		}	
		
		assertEquals("Checking to see that there is output in the file", true, scan.hasNext());
		
		scan.close();
		
	}
	
	@Test
	public void testpublic13x3Grid()
	{
		
		Plain testPlain = null;
		
		try {
			testPlain = new Plain("public1-3x3.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		assertEquals(State.GRASS, testPlain.grid[0][0].next(testPlain).who());
		assertEquals(State.FOX, testPlain.grid[0][1].next(testPlain).who());
		assertEquals(State.EMPTY, testPlain.grid[0][2].next(testPlain).who());
		assertEquals(State.EMPTY, testPlain.grid[1][0].next(testPlain).who());
		assertEquals(State.EMPTY, testPlain.grid[1][1].next(testPlain).who());
		assertEquals(State.FOX, testPlain.grid[1][2].next(testPlain).who());
		assertEquals(State.EMPTY, testPlain.grid[2][0].next(testPlain).who());
		assertEquals(State.FOX, testPlain.grid[2][1].next(testPlain).who());
		assertEquals(State.GRASS, testPlain.grid[2][2].next(testPlain).who());
		
		Plain secondPlain = new Plain(testPlain.getWidth());
		
		Wildlife.updatePlain(testPlain, secondPlain);
		
		assertEquals(State.GRASS, secondPlain.grid[0][0].who());
		assertEquals(State.FOX, secondPlain.grid[0][1].who());
		assertEquals(State.EMPTY, secondPlain.grid[0][2].who());
		assertEquals(State.EMPTY, secondPlain.grid[1][0].who());
		assertEquals(State.EMPTY, secondPlain.grid[1][1].who());
		assertEquals(State.FOX, secondPlain.grid[1][2].who());
		assertEquals(State.EMPTY, secondPlain.grid[2][0].who());
		assertEquals(State.FOX, secondPlain.grid[2][1].who());
		assertEquals(State.GRASS, secondPlain.grid[2][2].who());
		
		assertEquals(State.GRASS, secondPlain.grid[0][0].next(testPlain).who());
		assertEquals(State.EMPTY, secondPlain.grid[0][1].next(testPlain).who());
		assertEquals(State.FOX, secondPlain.grid[0][2].next(testPlain).who());
		assertEquals(State.FOX, secondPlain.grid[1][0].next(testPlain).who());
		assertEquals(State.FOX, secondPlain.grid[1][1].next(testPlain).who());
		assertEquals(State.EMPTY, secondPlain.grid[1][2].next(testPlain).who());
		assertEquals(State.EMPTY, secondPlain.grid[2][0].next(testPlain).who());
		assertEquals(State.EMPTY, secondPlain.grid[2][1].next(testPlain).who());
		assertEquals(State.GRASS, secondPlain.grid[2][2].next(testPlain).who());
		
		
	}
	
}
