package edu.iastate.cs228.hw1;

/**
 *  
 * @author Joseph Schmidt
 *
 */

/**
 * A fox eats rabbits and competes against a badger. 
 */
public class Fox extends Animal 
{
	/**
	 * Constructor 
	 * @param p: plain
	 * @param r: row position 
	 * @param c: column position
	 * @param a: age 
	 */
	
	public Fox (Plain p, int r, int c, int a) 
	{
		super(p, r, c, a);
	}
		
	/**
	 * A fox occupies the square. 	 
	 */
	public State who()
	{
		return State.FOX; 
	}
	
	/**
	 * A fox dies of old age or hunger, or from attack by numerically superior badgers. 
	 * @param pNew     plain of the next cycle
	 * @return Living  life form occupying the square in the next cycle. 
	 */
	public Living next(Plain pNew)
	{
		// TODO 
		// 
		// See Living.java for an outline of the function. 
		// See the project description for the survival rules for a fox. 
		
		super.census(livings);
		int badgers = livings[0];
		int empties = livings[1];
		int foxes = livings[2];
		int grasses = livings[3];
		int rabbits = livings[4];
		
		Living nextLiving;
		
		if(super.myAge() >= 6)
		{
			nextLiving = new Empty(pNew, super.row, super.column);
		}
		else if(badgers > foxes)
		{
			nextLiving = new Badger(pNew, super.row, super.column, 0);
		}
		else if((badgers + foxes) > rabbits)
		{
			nextLiving = new Empty(pNew, super.row, super.column);
		}
		else
		{
			nextLiving = new Fox(pNew, super.row, super.column, age + 1);
		}
		
		return nextLiving; 
	}
	
	@Override
	public String returnSymbol()
	{
		return "F" + age;
	}
	
}
