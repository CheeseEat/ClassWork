package edu.iastate.cs228.hw1;
import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 
import static org.junit.Assert.assertTrue; 
import static org.junit.Assert.assertFalse; 
import static org.junit.Assert.assertEquals; 
import static org.junit.Assert.fail; 


/*
 * @author Joseph Schmidt
 */
public class LivingTest {
	
	Wildlife w;
	Plain p;
	Plain oneByOne;
	Empty cornerEmpty;
	Empty middleEmpty;
	
	@Before
	public void setUp()
	{
			
		p = new Plain(3);
		oneByOne = new Plain(1);
		
//		p.grid = 
//		{
//			{new Empty(p, 0, 0), new Rabbit(p, 0, 1, 0), new Grass(p, 0, 2)},
//			{new Badger(p, 1, 0, 0), new Empty(p, 1, 1), new Grass(p, 1, 2)},
//			{new Fox(p, 2, 0, 0), new Grass(p, 2, 1), new Badger(p, 2, 2, 0)}
//		};
		
		oneByOne.grid[0][0] = new Empty(oneByOne, 0, 0);
		
		cornerEmpty = new Empty(p, 0, 0);
		middleEmpty = new Empty(p, 1, 1);
		
		p.grid[0][0] = cornerEmpty;
		p.grid[0][1] = new Rabbit(p, 0, 1, 0);
		p.grid[0][2] = new Grass(p, 0, 2);
	    p.grid[1][0] = new Badger(p, 1, 0, 0);
		p.grid[1][1] = middleEmpty;
		p.grid[1][2] = new Grass(p, 1, 2);
		p.grid[2][0] = new Fox(p, 2, 0, 0);
	    p.grid[2][1] = new Grass(p, 2, 1);
	    p.grid[2][2] = new Badger(p, 2, 2, 0);
		
				
				
	}
	
	@Test
	public void constructorTest()
	{
		Empty testEmpty = new Empty(p, 1, 1);
		assertEquals("checking plain", p, testEmpty.plain);
		assertEquals("checking row & column", true, testEmpty.row == 1 && testEmpty.column == 1);
	}
	
	
	//Badgers, Empties, Foxes, Grasses, and Rabbits
	@Test
	public void censusChecks()
	{
		p.grid[0][0].census(p.grid[0][0].livings);
		p.grid[1][1].census(p.grid[1][1].livings);
		
		//Testing to see that it picked up all of the neighbors for the corner Empty and that they are the correct neighbors
		assertEquals("Testing for 1 Badger as neighbor", true, cornerEmpty.livings[0] == 1);
		assertEquals("Testing for 2 Empties as neighbor, one being itself", true, cornerEmpty.livings[1] == 2);
		assertEquals("Testing for 0 Fox as neighbor", true, cornerEmpty.livings[2] == 0);
		assertEquals("Testing for 0 Grasses as neighbor", true, cornerEmpty.livings[3] == 0);
		assertEquals("Testing for 1 Rabbit as neighbor", true, cornerEmpty.livings[4] == 1);
		
		//Testing to see that the middle Empty is picking up all neighbors, and that they are correct
		assertEquals("Testing for 2 Badger as neighbors", true, middleEmpty.livings[0] == 2);
		assertEquals("Testing for 2 Empty as neighbor, one being iteself", true, middleEmpty.livings[1] == 2);
		assertEquals("Testing for 1 Fox as neighbor", true, middleEmpty.livings[2] == 1);
		assertEquals("Testing for 3 Grasses as neighbor", true, middleEmpty.livings[3] == 3);
		assertEquals("Testing for 1 Rabbit as neighbor", true, middleEmpty.livings[4] == 1);
		
		oneByOne.grid[0][0].census(oneByOne.grid[0][0].livings);
		
		//Testing a one by one grid to make sure it is only getting itself as a neighbor
		assertEquals("Testing for 1 Badger as neighbor", true, oneByOne.grid[0][0].livings[0] == 0);
		assertEquals("Testing for 2 Empties as neighbor, one being itself", true, oneByOne.grid[0][0].livings[1] == 1);
		assertEquals("Testing for 0 Fox as neighbor", true, oneByOne.grid[0][0].livings[2] == 0);
		assertEquals("Testing for 0 Grasses as neighbor", true, oneByOne.grid[0][0].livings[3] == 0);
		assertEquals("Testing for 1 Rabbit as neighbor", true, oneByOne.grid[0][0].livings[4] == 0);
		
	}
	
	
	
}
