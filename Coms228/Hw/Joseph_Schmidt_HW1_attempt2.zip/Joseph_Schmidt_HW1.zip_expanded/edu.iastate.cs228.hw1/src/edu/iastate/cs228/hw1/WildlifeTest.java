package edu.iastate.cs228.hw1;
import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 
import static org.junit.Assert.assertTrue; 
import static org.junit.Assert.assertFalse; 
import static org.junit.Assert.assertEquals; 
import static org.junit.Assert.fail; 

/*
 * @author Joseph Schmidt
 */
public class WildlifeTest {
	
	Wildlife w;
	Plain p;
	
	@Before
	public void setUp()
	{
			
		p = new Plain(3);
		
		p.grid[0][0] = new Rabbit(p, 0, 0, 0);
		p.grid[0][1] = new Rabbit(p, 0, 1, 0);
		p.grid[0][2] = new Badger(p, 0, 2, 0);
	    p.grid[1][0] = new Grass(p, 1, 0);
		p.grid[1][1] = new Grass(p, 1, 1);
		p.grid[1][2] = new Empty(p, 1, 2);
		p.grid[2][0] = new Grass(p, 2, 0);
	    p.grid[2][1] = new Empty(p, 2, 1);
	    p.grid[2][2] = new Grass(p, 2, 2);
				
	}
	
	@Test
	public void updatePlainTest()
	{
		
		//Testing that the updatePlain function runs and that it change the correct Living objects in the plain given to it
		
		Plain plainNew = new Plain(3);
		
		Wildlife.updatePlain(p, plainNew);
		
		Rabbit zeroZero = (Rabbit) plainNew.grid[0][0];
		Rabbit zeroOne = (Rabbit) plainNew.grid[0][1];
		Badger zeroTwo = (Badger) plainNew.grid[0][2];
		Grass oneZero = (Grass)plainNew.grid[1][0];
		Grass oneOne = (Grass)plainNew.grid[1][1];
		Grass oneTwo = (Grass)plainNew.grid[1][2];
		Grass twoZero = (Grass)plainNew.grid[2][0];
		Grass twoOne = (Grass)plainNew.grid[2][1];
		Grass twoTwo = (Grass)plainNew.grid[2][2];
		
		assertEquals(State.RABBIT, zeroZero.who());
		assertEquals(1, zeroZero.age);
		assertEquals(State.RABBIT, zeroOne.who());
		assertEquals(1, zeroOne.age);
		assertEquals(State.BADGER, zeroTwo.who());
		assertEquals(1, zeroTwo.age);
		assertEquals(State.GRASS, oneZero.who());
		assertEquals(State.GRASS, oneOne.who());
		assertEquals(State.GRASS, oneTwo.who());
		assertEquals(State.GRASS, twoZero.who());
		assertEquals(State.GRASS, twoOne.who());
		assertEquals(State.GRASS, twoTwo.who());
		
	}
	
}
