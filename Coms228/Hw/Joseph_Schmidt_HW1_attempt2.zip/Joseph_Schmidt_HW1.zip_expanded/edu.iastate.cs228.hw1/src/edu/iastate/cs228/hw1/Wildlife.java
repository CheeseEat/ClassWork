package edu.iastate.cs228.hw1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner; 

/**
 *  
 * @author Joseph Schmidt
 *
 */

/**
 * 
 * The Wildlife class performs a simulation of a grid plain with
 * squares inhabited by badgers, foxes, rabbits, grass, or none. 
 *
 */
public class Wildlife 
{
	/**
	 * Update the new plain from the old plain in one cycle. 
	 * @param pOld  old plain
	 * @param pNew  new plain 
	 */
	public static void updatePlain(Plain pOld, Plain pNew)
	{
		// TODO 
		// 
		// For every life form (i.e., a Living object) in the grid pOld, generate  
		// a Living object in the grid pNew at the corresponding location such that 
		// the former life form changes into the latter life form. 
		// 
		// Employ the method next() of the Living class. 
		
		for(int row = 0; row < pOld.getWidth(); row++)
		{
			for(int col = 0; col < pOld.getWidth(); col++)
			{
				
				Living curLiving = pOld.grid[row][col];
				Living nextLiving = curLiving.next(pNew);
				pNew.grid[row][col] = nextLiving;
				
			}
			
		}
		
	}
	
	/**
	 * Repeatedly generates plains either randomly or from reading files. 
	 * Over each plain, carries out an input number of cycles of evolution. 
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException
	{	
		// TODO 
		// 
		// Generate wildlife simulations repeatedly like shown in the 
		// sample run in the project description. 
		// 
		// 1. Enter 1 to generate a random plain, 2 to read a plain from an input
		//    file, and 3 to end the simulation. (An input file always ends with 
		//    the suffix .txt.)
		// 
		// 2. Print out standard messages as given in the project description. 
		// 
		// 3. For convenience, you may define two plains even and odd as below. 
		//    In an even numbered cycle (starting at zero), generate the plain 
		//    odd from the plain even; in an odd numbered cycle, generate even 
		//    from odd. 
		
		Scanner scan = new Scanner(System.in);
		String fileName;
		int option = -1;
		Plain plain = null;
		int numberIterations = 0;
		
		//FileInputStream fileInStream;
		//Scanner fileScanner;
		
		while(option == -1)
		{
			try
			{
				
				System.out.println("Input 1, 2, or 3");
				
				option = scan.nextInt();
				scan.nextLine();
				
				if(option < 1 || option > 3)
				{
					System.out.println("Invalid Integer, Try Again");
					option = -1;
				}
				
				if(option == 1)
				{
					Random random = new Random();
					int randInt = 3;//random.nextInt(14) + 2;
					plain = new Plain(randInt);
					plain.randomInit();
				}
				
				if(option == 2)
				{
					
					System.out.println("Input File Name: ");
					fileName = scan.nextLine();
					plain = new Plain(fileName);

				}
				
				if(option == 3)
				{
					return;
				}
				
				if(option == 1 || option == 2)
				{
					System.out.println("Input Number of Iterations: ");
					numberIterations = scan.nextInt();
				}
				
			}
			catch(InputMismatchException e)
			{
				option = -1;
				System.out.println("Invalid Input, Try Again\n");
				scan.nextLine();
			}
			catch(FileNotFoundException f)
			{
				option = -1;
				System.out.println("Invalid File Name, Try Again");
			}
			
		}
		
		scan.close();
		
		
		
		// 4. Print out initial and final plains only.  No intermediate plains should
		//    appear in the standard output.  (When debugging your program, you can 
		//    print intermediate plains.)
		// 
		// 5. You may save some randomly generated plains as your own test cases. 
		// 
		// 6. It is not necessary to handle file input & output exceptions for this 
		//    project. Assume data in an input file to be correctly formated. 
		
		if(plain != null)
		{
			
			Plain even = new Plain(plain.getWidth());   				 // the plain after an even number of cycles 
			Plain odd = new Plain(plain.getWidth());                   // the plain after an odd number of cycles
			
			System.out.println(plain.toString());
			
			if(numberIterations > 0)
			{
				updatePlain(plain, odd);
				
				if(numberIterations == 1) System.out.println(odd.toString());
				
			}
			
			for(int i = 1; i < numberIterations; i++)
			{
				if(i % 2 == 0)
				{
					updatePlain(even, odd);
					
					//System.out.println(odd.toString());
					
					if(i == numberIterations - 1)
					{
						System.out.println(odd.toString());
					}
					
				}
				else
				{
					updatePlain(odd, even);
					
					//System.out.println(even.toString());
					
					if(i == numberIterations - 1)
					{
						System.out.println(even.toString());
					}
					
				}
				
			}
			
					
			
		}
		
	}
}
