package edu.iastate.cs228.hw1;
import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 
import static org.junit.Assert.assertTrue; 
import static org.junit.Assert.assertFalse; 
import static org.junit.Assert.assertEquals; 
import static org.junit.Assert.fail; 

/*
 * @author Joseph Schmidt
 */

public class FoxTest {
	
	Wildlife w;
	Plain p;
	
	Fox cornerFox;
	Fox middleFox;
	
	@Before
	public void setUp()
	{
			
		p = new Plain(3);
		
//		p.grid = 
//		{
//			{new Fox(p, 0, 0, 0), new Rabbit(p, 0, 1, 0), new Grass(p, 0, 2)},
//			{new Badger(p, 1, 0, 0), new Fox(p, 1, 1, 0), new Grass(p, 1, 2)},
//			{new Fox(p, 2, 0, 0), new Grass(p, 2, 1), new Empty(p, 2, 2)}
//		};
		
		cornerFox = new Fox(p, 0, 0, 0);
		middleFox = new Fox(p, 1, 1, 0);
		
		p.grid[0][0] = cornerFox;
		p.grid[0][1] = new Rabbit(p, 0, 1, 0);
		p.grid[0][2] = new Grass(p, 0, 2);
	    p.grid[1][0] = new Badger(p, 1, 0, 0);
		p.grid[1][1] = middleFox;
		p.grid[1][2] = new Grass(p, 1, 2);
		p.grid[2][0] = new Fox(p, 2, 0, 0);
	    p.grid[2][1] = new Grass(p, 2, 1);
	    p.grid[2][2] = new Empty(p, 2, 2);
		
				
				
	}
	
	@Test
	public void constructorTest()
	{
		Fox testFox = new Fox(p, 1, 1, 0);
		assertEquals("checking plain", p, testFox.plain);
		assertEquals("checking row & column", true, testFox.row == 1 && testFox.column == 1);
		assertEquals("Checking age", 0, testFox.age);
	}
	
	@Test 
	public void whoTest()
	{
		Fox testFox = new Fox(p, 1, 1, 0);
		assertEquals("Checking who, should return Fox", State.FOX, testFox.who());
	}
	
	@Test
	public void updatePlainBadgerAge()
	{
		
		//Checking that at age 6, after the next updatePlain call it's location is replaced with an EMPTY
		p.grid[1][1] = new Fox(p, 1, 1, 6);
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleFox = pNew.grid[1][1];
		
		assertEquals("Should be Empty", State.EMPTY, newMiddleFox.who());	
		
	}
	
	@Test
	public void updatePlainMoreBadgersThanFoxes()
	{
		
		//Checking to see if there are more badgers than there are foxes than should be badger
		p.grid[0][0] = new Badger(p, 0, 0, 0);
		p.grid[2][0] = new Badger(p, 2, 0, 0);
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleFox = pNew.grid[1][1];
		
		assertEquals("Should be Badger", State.BADGER, newMiddleFox.who());	
		
	}
	
	@Test
	public void updatePlainMoreFoxesBadgersThanRabbits()
	{
		
		//Checking to see if more foxes and badgers in neighborhood than rabbits should be empty
		//The plain is already set up to match this test case
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleFox = pNew.grid[1][1];
		
		assertEquals("Should be Empty", State.EMPTY, newMiddleFox.who());	
		
	}
	
	@Test
	public void updatePlainFoxLiveOn()
	{
		
		//Checking to see if more foxes and badgers in neighborhood than rabbits should be empty
		//The plain is already set up to match this test case
		
		p.grid[0][0] = new Rabbit(p, 0, 0, 0);
		p.grid[1][0] = new Rabbit(p, 1, 0, 0);
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleFox = pNew.grid[1][1];
		Fox newMiddleEmptyFox = (Fox) newMiddleFox;
		
		assertEquals("Should be Fox", State.FOX, newMiddleFox.who());	
		assertEquals("Should be age 1", 1, newMiddleEmptyFox.age);
		
	}
	
}
