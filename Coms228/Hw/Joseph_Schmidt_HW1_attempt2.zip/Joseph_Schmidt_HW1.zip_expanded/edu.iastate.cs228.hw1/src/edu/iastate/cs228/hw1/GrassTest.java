package edu.iastate.cs228.hw1;
import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 
import static org.junit.Assert.assertTrue; 
import static org.junit.Assert.assertFalse; 
import static org.junit.Assert.assertEquals; 
import static org.junit.Assert.fail; 

/*
 * @author Joseph Schmidt
 */

public class GrassTest {
	
	Wildlife w;
	Plain p;
	
	Grass cornerGrass;
	Grass middleGrass;
	
	@Before
	public void setUp()
	{
			
		p = new Plain(3);
		
//		p.grid = 
//		{
//			{new Grass(p, 0, 0), new Rabbit(p, 0, 1, 0), new Grass(p, 0, 2)},
//			{new Badger(p, 1, 0, 0), new Grass(p, 1, 1), new Grass(p, 1, 2)},
//			{new Fox(p, 2, 0, 0), new Grass(p, 2, 1), new Empty(p, 2, 2)}
//		};
		
		cornerGrass = new Grass(p, 0, 0);
		middleGrass = new Grass(p, 1, 1);
		
		p.grid[0][0] = cornerGrass;
		p.grid[0][1] = new Rabbit(p, 0, 1, 0);
		p.grid[0][2] = new Grass(p, 0, 2);
	    p.grid[1][0] = new Badger(p, 1, 0, 0);
		p.grid[1][1] = middleGrass;
		p.grid[1][2] = new Grass(p, 1, 2);
		p.grid[2][0] = new Fox(p, 2, 0, 0);
	    p.grid[2][1] = new Grass(p, 2, 1);
	    p.grid[2][2] = new Empty(p, 2, 2);
		
				
				
	}
	
	@Test
	public void constructorTest()
	{
		Grass testGrass = new Grass(p, 1, 1);
		assertEquals("checking plain", p, testGrass.plain);
		assertEquals("checking row & column", true, testGrass.row == 1 && testGrass.column == 1);
	}
	
	@Test 
	public void whoTest()
	{
		Grass testGrass = new Grass(p, 1, 1);
		assertEquals("Checking who, should return RABBIT", State.GRASS, testGrass.who());
	}
	
	@Test
	public void updatePlainThreeTimesRabbits()
	{
		//Checking to see if there are three times the amount of rabbits as grasses the next update plain should turn
		//current cell to EMPTY
		p.grid[0][0] = new Rabbit(p, 0, 0, 0);
		p.grid[0][2] = new Rabbit(p, 0, 2, 0);
		p.grid[1][2] = new Rabbit(p, 1, 2, 0);
		p.grid[2][0] = new Rabbit(p, 2, 0, 0);
		p.grid[2][2] = new Rabbit(p, 2, 2, 0);
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleGrass = pNew.grid[1][1];
		
		assertEquals("Should be EMPTY", State.EMPTY, newMiddleGrass.who());	
	}
	
	@Test
	public void updatePlainAtleastThreeRabbits()
	{
		//Checking to see if there are at least three rabbits in the neighbors and that the rabbits
		//are not three times the amount of grass
		
		p.grid[0][0] = new Rabbit(p, 0, 0, 0);
		p.grid[2][1] = new Rabbit(p, 2, 1, 0);
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleGrass = pNew.grid[1][1];
		
		assertEquals("Should be RABBIT", State.RABBIT, newMiddleGrass.who());
		
	}
	
	@Test
	public void updateGrass()
	{
		
		//Grass Living on if there is not three times the amount or Rabbits or if there is not three rabbits in the neighborhood
		
		//Default grid has this case set up
		
		Plain pNew = new Plain(3);
		Wildlife.updatePlain(p, pNew);
		
		Living newMiddleGrass = pNew.grid[1][1];
		Grass newMiddleEmptyGrass = (Grass) newMiddleGrass;
		
		assertEquals("Should be Grass", State.GRASS, newMiddleGrass.who());	
		
	}
	
}
