package edu.iastate.cs228.hw1;

/**
 *  
 * @author Joseph Schmidt
 *
 */

/**
 * Grass remains if more than rabbits in the neighborhood; otherwise, it is eaten. 
 *
 */
public class Grass extends Living 
{
	public Grass (Plain p, int r, int c) 
	{
		super(p, r, c); 
	}
	
	public State who()
	{  
		return State.GRASS; 
	}
	
	/**
	 * Grass can be eaten out by too many rabbits. Rabbits may also multiply fast enough to take over Grass.
	 */
	public Living next(Plain pNew)
	{
		// TODO 
		// 
		// See Living.java for an outline of the function. 
		// See the project description for the survival rules for grass. 
		
		super.census(livings);
		int badgers = livings[0];
		int empties = livings[1];
		int foxes = livings[2];
		int grasses = livings[3];
		int rabbits = livings[4];
		
		Living nextLiving;
		
		if((rabbits / 3) >= grasses)
		{
			nextLiving = new Empty(pNew, super.row, super.column);
		}
		else if(rabbits >= 3)
		{
			nextLiving = new Rabbit(pNew, super.row, super.column, 0);
		}
		else
		{
			nextLiving = new Grass(pNew, super.row, super.column);
		}
		
		return nextLiving; 
	}
	
	@Override
	public String returnSymbol()
	{
		return "G ";
	}
	
}
