package hw2;

import api.ThrowType;
import static api.ThrowType.*;

/**
 * This class models a standard game of darts, keeping track of the scores,
 * whose turn it is, and how many darts the current player has remaining. The
 * number of starting points and the number of darts used in a player's turn are
 * configurable.
 * 
 * @author Joseph Schmidt
 */
public class DartGame {
	
	/**
	 * Keeps track of the score for player 0.
	 */
	private int scorePlayer0;
	
	/**
	 * Keeps track of the score for player 1.
	 */
	private int scorePlayer1;
	
	/**
	 * Keeps track of who the current player is.
	 */
	private int currentPlayer;
	
	/**
	 * Keeps track of the amount of darts for player 0.
	 */
	private int dartCount;
	
	/**
	 * Keeps track of the score at the start of the turn of the current player.
	 */
	private int startScore;
	
	/**
	 * Keeps track of whether player0 has doubled in yet.
	 */
	private boolean player0DoubleIn = false;
	
	/**
	 * Keeps track of whether player1 has doubled in yet.
	 */
	private boolean player1DoubleIn = false;
	
	/**
	 * For when you switch players and need to reset the darts back to the amount specified when calling the constructor.
	 */
	private int constantDartCount;
	
	/**
	 * Constructor for the DartGame class. 
	 * 
	 * @param startingPlayer
	 * The starting player (0 or 1).
	 * @param numberOfPoints
	 * The wanted number of points that players start with.
	 * @param numberOfDarts
	 * The wanted number of darts for each player.
	 */
	public DartGame(int startingPlayer, int numberOfPoints, int numberOfDarts){
		scorePlayer0 = numberOfPoints;
		scorePlayer1 = numberOfPoints;
		currentPlayer = startingPlayer;
		dartCount = numberOfDarts;
		constantDartCount = numberOfDarts;
		startScore = numberOfPoints;
	}
	
	/**
	 * Default constructor if only the starting player is given.
	 * 
	 * @param The number of the starting player (0 or 1).
	 */
	public DartGame(int startingPlayer) {
		scorePlayer0 = 301;
		scorePlayer1 = 301;
		currentPlayer = startingPlayer;
		dartCount = 3;
		constantDartCount = 3;
		startScore = 301;
	}

	/**
	 * Returns the player whose turn it is. (When the game is over, this method
	 * always returns the winning player.)
	 * 
	 * @return current player (0 or 1)
	 */
	public int getCurrentPlayer() {
		return currentPlayer;
	}

	/**
	 * Returns the score of the indicated player (0 or 1). If the argument is any
	 * value other than 0 or 1, the method returns -1.
	 * 
	 * @param which indicator for which player (0 or 1)
	 * @return score for the indicated player, or -1 if the argument is invalid
	 */
	public int getScore(int which) {
		if(which == 0) {
			return scorePlayer0;
		} else if (which == 1){
			return scorePlayer1;
		} 
		//else
		return -1;

	}
	
	/**
	 * Returns the number of darts left in the current player's turn.
	 * 
	 * @return the number of darts left in the current player's turn
	 */
	public int getDartCount() {
		return dartCount;
	}

	/**
	 * Returns a string representation of the current game state.
	 */
	public String toString() {
		String result = "Player 0: " + getScore(0) + "  Player 1: " + getScore(1) + "  Current: Player "
				+ getCurrentPlayer() + "  Darts: " + getDartCount();
		return result;
	}
	
	/**
	 * Simulates the current player throwing a dart and adjusts the score, the player's dart count, and whose turn it is, as needed.
	 * @param type
	 * What type of shot it was such as: single, double, triple, or bullseye.
	 * @param number
	 * What number the dart landed on.
	 */
	public void throwDart(ThrowType type, int number) {
		
		if(dartCount > 0 && !isOver()) {	
			
			dartCount -= 1;
			
			changeDoubledIn(type);
			
			if(checkDoubledIn()) {
				
				int tempScore = calcPoints(type, number);
				
				adjustScore(tempScore);
				
				if(bust(getScore(currentPlayer)) || (isOver() && (type != DOUBLE && type != INNER_BULLSEYE))) {
					
					setScore(currentPlayer, startScore);
					switchPlayer();
						
				} 
			} 
			if (dartCount == 0 && !isOver()) {
				switchPlayer();
			}
		}
			
	}
	
	/**
	 * Function that checks to see if the current player has doubled in or not.
	 * @return
	 * Boolean of whether the player has doubled in or not.
	 */
	private boolean checkDoubledIn() {
		if(currentPlayer == 0) {
			return (player0DoubleIn);
		} 
		//else player 1, return its state.
		return (player1DoubleIn);
	}
	
	/**
	 * Method to change the current players doubled in status if they throw a double or inner bullseye.
	 * @param type
	 * The type of throw that was thrown. 
	 */
	private void changeDoubledIn(ThrowType type) {
		if(type == DOUBLE || type == INNER_BULLSEYE) {
			if(currentPlayer == 0) {
				player0DoubleIn = true;
			} else {
				player1DoubleIn = true;
			}
		}
	}

	/**
	 * Sets the score to given value.
	 * @param playerNumber
	 * What player's score you want to adjust.
	 * @param score
	 * What score you want to adjust the player's score to.
	 */
	private void setScore(int playerNumber, int score) {
		if(playerNumber == 1) {
			scorePlayer1 = score;
		} else {
			scorePlayer0 = score;
		}
	}
	
	/**
	 * Calculates the amount of points scored on a throw.
	 * @param type
	 * Where the dart landed on the bored and what type it is. Example: Double points, triple points...
	 * @param amount
	 * What number was hit on the board.
	 * @return
	 * The calculated amount of points for the throw.
	 */
	public static int calcPoints(ThrowType type, int amount) {
		
		if(type == MISS) {
			
			amount = 0;
			
		} else if (type == SINGLE) {		
				
			amount = amount; 
			
		} else if (type == DOUBLE) {
			
			amount *= 2;
			
		} else if (type == TRIPLE) {
			
			amount *= 3;
			
		} else if (type == OUTER_BULLSEYE) {
			
			amount = 25;
			
		} else if (type == INNER_BULLSEYE) {
			
			amount = 50;
			
		} else {
			
			//In case the user puts in an invalid type
			amount = -1;
			
		}
		
		return amount;
		
	}
	
	/**
	 * Checks to see if the score when under 0 or is at 1.
	 * @param amount
	 * The amount the score is changing.
	 * @return
	 * Whether the score change will result in a bust.
	 */
	private boolean bust (int amount) {
		
		if(amount < 0 || amount == 1) {
			return true;
		}
		return false;
		
	
	}
	
	/**
	 * Returns whether the game points is currently at 0 for a given player.
	 * @return
	 * Boolean of whether or not the points are at 0.
	 */
	public boolean isOver() {
		if(getScore(currentPlayer) == 0) {
			return true;
		}
		//else
		return false;
	}
	
	/**
	 * Returns the winning player.
	 * @return
	 * An integer representing the player number of who won. Returns -1 if there is no current winner.
	 */
	public int whoWon() {
		if(isOver()) {
			return currentPlayer;
		}
		//else
		return -1;
	}
	
	/**
	 * Reduces the score for the current player by the given amount.
	 * @param amount
	 * 	number of points to subtract.
	 */
	private void adjustScore(int amount) {
		
		if(currentPlayer == 0) {
			scorePlayer0 -= amount;
		} else { 
			scorePlayer1 -= amount;
		}
	
	}
	
	/**
	 * Switches players and resets the dart count and the starting score for the current player's turn.
	 */
	private void switchPlayer() {
		
		if(currentPlayer == 0) {
			
			currentPlayer = 1;
			startScore = scorePlayer1;
		
		} else {
			//Current player is 1
			
			currentPlayer = 0;
			startScore = scorePlayer0;
		
		}
		
		dartCount = constantDartCount;
		
	}

}