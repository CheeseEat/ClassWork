package hw4;

import static api.Direction.DOWN;
import static api.Direction.LEFT;
import static api.Direction.RIGHT;
import static api.Direction.UP;
import static api.Mode.INACTIVE;

import api.Actor;
import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

/**
 * Player class for a Pacman game.
 * @author smkautz
 */
public class Pacman extends Character
{
  
	/**
	 * Flag indicating that the player is in "turning" mode, that is, moving on a
	 * diagonal in a new direction of travel and simultaneously in the previous
	 * direction of travel.
	 */
	private boolean turning;

	/**
	 * When in turning mode, records the previous direction of travel.
	 */
	private Direction previousDirection;

	/**
	 * When in turning mode, records the centerline of the new row or column.
	 */
	private double turnTarget;

	/**
	 * Constructs a new Pacman with the given maze, home location, base speed, and
	 * initial direction.
	 * 
	 * @param maze          maze configuration
	 * @param home          initial location
	 * @param baseSpeed     base speed increment
	 * @param homeDirection initial direction
	 */
	public Pacman(MazeMap maze, Location home, double baseSpeed, Direction homeDirection) {

		super(maze, home, baseSpeed, homeDirection);

	}

	@Override
	public Mode getMode() {
		// does nothing
		return null;
	}

	@Override
	public void reset() {

		super.reset();
		turning = false;

	}

	@Override
	public void setMode(Mode mode, Descriptor desc) {
		// does nothing
	}

	/**
	 * Attempts to set the direction to the given new direction. This may occur
	 * slightly before reaching the new row or column, allowing the player to "cut"
	 * the corner; in that case, we enter "turning" mode: this sets the new
	 * direction, but also remembers the previous direction in order to keep moving
	 * along the previous direction as well as the new direction until aligned with
	 * the new row or column.
	 * 
	 * @param newDir desired direction of travel for the player
	 */
	public void tryTurn(Direction newDir) {
		if (turning) {
			// can't change direction in the middle of a turn
			return;
		}

		// easy cases first: not actually changing direction, just maybe reversing
		Direction currentDir = getCurrentDirection();
		if (((newDir == LEFT || newDir == RIGHT) && (currentDir == LEFT || currentDir == RIGHT || currentDir == null))
				|| ((newDir == UP || newDir == DOWN)
						&& (currentDir == UP || currentDir == DOWN || currentDir == null))) {
			// currentDirection = newDir;
			setDirection(newDir);
			return;
		}

		double rowPos = getRowExact();
		double colPos = getColExact();
		int colNum = (int) getColExact();
		int rowNum = (int) getRowExact();

		// max distance before new row/column that we can start a turn
		double tolerance = 1.0;

		int newColNum = colNum;
		int newRowNum = rowNum;
		double diff = 0;

		if (newDir == LEFT || newDir == RIGHT) {
			// Idea - figure out whether a turn is possible within the next 'tolerance'
			// cell units, which could include the current cell or one cell ahead.
			// So, if we are before the center of current cell, possible turn direction
			// is the cell to left or right. But if we are past the center of current
			// cell, then possible turn is at the *next* row left or right.

			// Note: if we are currently in the tunnel, that is ok because
			// we can't be currently moving up or down
			newColNum = newDir == Direction.LEFT ? colNum - 1 : colNum + 1;
			if (currentDir == Direction.UP) {
				// distance to center
				diff = rowPos - ((int) rowPos) - 0.5;
				if (diff < 0) {
					// past the center, we must be trying to turn at next cell up
					diff = diff + 1;
					newRowNum -= 1;
				}
			} else if (currentDir == Direction.DOWN) {
				diff = 0.5 - (rowPos - ((int) rowPos));
				if (diff < 0) {
					// past the center, try next cell up
					diff = diff + 1;
					newRowNum += 1;
				}
			}
		} else {
			// Note: if we are currently in the tunnel, this is still ok because
			// we are only checking walls based on the current column number
			newRowNum = newDir == Direction.UP ? rowNum - 1 : rowNum + 1;
			if (currentDir == Direction.LEFT) {
				diff = colPos - ((int) colPos) - 0.5;
				if (diff < 0) {
					diff += 1;
					newColNum -= 1;
				}
			} else if (currentDir == Direction.RIGHT) {
				diff = 0.5 - (colPos - colNum);
				if (diff < 0) {
					diff += 1;
					newColNum += 1;
				}
			}
		}

		if (diff >= 0 && diff < tolerance && !getMaze().isWall(newRowNum, newColNum)) {
			// after all that, we can actually decide to turn!
			setDirection(newDir);

			// if we are not exactly aligned with new direction, then
			// go into 'turning' mode and continue to adjust along previous
			// direction with the next few update() calls. For this, we
			// need the previous direction, and it is also helpful to
			// record the centerline for the desired new row or column
			// (the 'turnTarget').
			if (diff > 0) {
				turning = true;
				previousDirection = currentDir;
				if (currentDir == UP || currentDir == DOWN) {
					// centerline of new row
					turnTarget = newRowNum + 0.5;
				} else {
					// centerline of new column
					turnTarget = newColNum + 0.5;
				}
			}
		}
	}

	/**
	 * When in "turning" mode, we need to update along the previous direction of
	 * travel until lined up with the new row or column.
	 */
	private void handleTurn() {
		double increment = getCurrentIncrement();
		double curRowExact = getRowExact();
		double curColExact = getColExact();

		if (previousDirection == UP) {
			// when up or down, turnTarget is center of target row
			double distanceToGo = curRowExact - turnTarget;
			if (increment >= distanceToGo - ERR) {
				increment = distanceToGo;

				// we've reached the center, so done with turning mode
				turning = false;
			}
			curRowExact -= increment;
		} else if (previousDirection == DOWN) {
			double distanceToGo = turnTarget - curRowExact;
			if (increment >= distanceToGo - ERR) {
				increment = distanceToGo;
				turning = false;
			}
			curRowExact += increment;
		} else if (previousDirection == LEFT) {
			// when left or right, turnTarget is center of target column
			double distanceToGo = curColExact - turnTarget;
			if (increment >= distanceToGo - ERR) {
				increment = distanceToGo;
				turning = false;
			}
			curColExact -= increment;
		} else if (previousDirection == RIGHT) {
			double distanceToGo = turnTarget - curColExact;
			if (increment >= distanceToGo - ERR) {
				increment = distanceToGo;
				turning = false;
			}
			curColExact += increment;
		}

		// finally, update instance vars
		setRowExact(curRowExact);
		setColExact(curColExact);
	}
	
	/*
	 * Checks before the update method.
	 */
	@Override
	protected void preUpdateChecks(Descriptor d) {

		if (turning) {
			handleTurn();
		}

	}

	@Override
	protected void potentialCellCheck(Descriptor d) {
		
		//Do nothing

	}

	@Override
	protected boolean extraBoolean(double diff) {
		
		//Do nothing
		return false;
		
	}
	
	@Override
	protected void extraUpdateCode() {
		
		//Do nothing

	}
	
	/*
	 * Return if there is no current direction
	 */
	@Override
	protected boolean returnConditions() {
		return (getCurrentDirection() == null);
	}


}
