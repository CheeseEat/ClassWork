package hw4;

import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;
import static api.Direction.DOWN;
import static api.Direction.LEFT;
import static api.Direction.RIGHT;
import static api.Direction.UP;
import static api.Mode.INACTIVE;
import static api.Mode.DEAD;
import static api.Mode.FRIGHTENED;
import static api.Mode.SCATTER;
import static api.Mode.CHASE;

import java.util.Random;

/*
 * Blinky class
 * 
 * @author Joseph Schmidt
 */
public class Blinky extends Ghosts{
	
	public Blinky(MazeMap maze, Location home, double baseSpeed, Direction homeDirection, Location givenScatterTarget, Random givenRandomNumber)
	{
		
		super(maze, home, baseSpeed, homeDirection, givenScatterTarget, givenRandomNumber);
		
	}

	/*
	 * Implements the target location for Blinky when in CHASE mode. This location Pacman's location.
	 */
	@Override
	protected Location findChaseTargetLocation(Descriptor desc)
	{
		return desc.getPlayerLocation();
	}
	
}

