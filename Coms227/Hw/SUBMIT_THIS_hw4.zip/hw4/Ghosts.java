package hw4;

import static api.Direction.DOWN;
import static api.Direction.LEFT;
import static api.Direction.RIGHT;
import static api.Direction.UP;
import static api.Mode.CHASE;
import static api.Mode.DEAD;
import static api.Mode.FRIGHTENED;
import static api.Mode.INACTIVE;
import static api.Mode.SCATTER;

import java.util.Random;

import api.Actor;
import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

/*
 * Parent class for ghosts
 * 
 * @author Joseph Schmidt
 */
public abstract class Ghosts extends Character {
	
	  /*
	   * Keeps track of the next location.
	   */
	  private Location nextLoc;
	  
	  /*
	   * Random variable for when ghost is in FRIGHTENED mode deciding where to go next
	   */
	  private Random rand;
	  
	  /*
	   * Location where the ghost needs to go during SCATTER mode.
	   */
	  private Location scatterLocation;
	  
	  /*
	   * Keeps track of the next direction for the ghost.
	   */
	  private Direction nextDir;
	  
	  
	  
	  /**
	   * Constructs a new Sprite with the given maze, home location, base speed,
	   * and initial direction.
	   * @param maze
	   *   maze configuration
	   * @param home
	   *   initial location
	   * @param baseSpeed
	   *   base speed increment
	   * @param homeDirection
	   *   initial direction
	   */
	  public Ghosts(MazeMap maze, Location home, double baseSpeed, Direction homeDirection, Location scatterLocation, Random random)
	  {
	    super(maze, home, baseSpeed, homeDirection);
	    this.scatterLocation = scatterLocation;
	    rand = random;
	    setDirection(UP);
	  }
	  
	  public Location getScatterLocation()
	  {
		  return scatterLocation;
	  }
	  
	  @Override
	  public void reset()
	  {
		  super.reset();
		  nextLoc = null;
		  nextDir = null;

	  }

	  @Override
	  public void setMode(Mode mode, Descriptor desc) {
			
			super.setMode(mode, desc);
			calculateNextCell(desc);
			
		}
	  
	  
	  public void setNextLoc(Location givenLocation)
	  {
		  nextLoc = givenLocation;
	  }
	
	  
	  /*
	   * Find the direction needed to get to the next location
	   */
	  private Direction findCurrentDirection() {
		
		  Location locationWantToGetTo = nextLoc;
		  Location currentLocation = getCurrentLocation();
		  int locationWantToGetToRow = locationWantToGetTo.row();
		  int locationWantToGetToCol = locationWantToGetTo.col();
		  int currentLocationRow = currentLocation.row();
		  int currentLocationCol = currentLocation.col();
		  
		  int rowDiff = currentLocationRow - locationWantToGetToRow;
		  int colDiff = currentLocationCol - locationWantToGetToCol;
		  
		  if(rowDiff == -1)
		  {
			  return DOWN; 
		  }
		  else if(rowDiff == 1)
		  {
			  return UP; 
		  }
		  else if(colDiff == -1)
		  {
			  return RIGHT; 
		  }
		  else
		  {
			  return LEFT; 
		  }
		  
	  }
	  
	  /*
	   * Finds the length of a line between two locations.
	   */
	  protected double findLineLength(Location pointOne, Location pointTwo)
		{
			
			int pointOneRow = pointOne.row();
			int pointOneCol = pointOne.col();
			int pointTwoRow = pointTwo.row();
			int pointTwoCol = pointTwo.col();
			
			double rowDiff = pointOneRow - pointTwoRow;
			double colDiff = pointOneCol - pointTwoCol;
			
			double distance = Math.sqrt(Math.pow(rowDiff, 2) + Math.pow(colDiff, 2));
			
			return distance;
			
		}
	  
	  /*
	   * Does the calculation in finding where the ghost should go next
	   */
	  protected void calculation(Descriptor desc, Location targetLocation)
		{
		    
		  	if(getCurrentDirection() != null)
			{
				double distanceFromCenter = distanceToCenter();
				
				if(distanceFromCenter < 0)
				{
					
					return;
				
				}
				
			}
			
		  	Location currentLoc = getCurrentLocation();
			
			boolean up = true;
			boolean left = true;
			boolean down = true;
			boolean right = true;
			
			double upLength; double leftLength; double downLength; double rightLength;
			
			int upRow = currentLoc.row() - 1; int upCol = currentLoc.col();
			int leftRow = currentLoc.row(); int leftCol = currentLoc.col() - 1;
			int downRow = currentLoc.row() + 1; int downCol = currentLoc.col();
			int rightRow = currentLoc.row(); int rightCol = currentLoc.col() + 1;
			
			Location upLocation = new Location(upRow, upCol);
			Location leftLocation = new Location(leftRow, leftCol);
			Location downLocation = new Location(downRow, downCol);
			Location rightLocation = new Location(rightRow, rightCol);
			
			Direction[] directions = {UP, LEFT, DOWN, RIGHT};
			MazeMap currentMaze = getMaze();
			Direction currentDirection = getCurrentDirection();
			
			//If the one of the test locations wraps around to the other side of the map sets it to that location
			if(leftCol < 0)
			{
				
				leftCol = getMaze().getNumColumns() - 1;
				
				if(currentDirection == LEFT)
				{
					leftLocation = new Location(leftRow, leftCol);
				}
				
			}
			if(rightCol > getMaze().getNumColumns() - 1)
			{
				
				rightCol = 0;
				
				if(currentDirection == RIGHT)
				{
					rightLocation = new Location(rightRow, rightCol);
				}
				
			}
			
			Location[] directionLocations = {upLocation, leftLocation, downLocation, rightLocation};
			
			
			
			//Make sure your not reversing and going to where you came from
			//Special Case: If statement for if the ghost is FRIGHTENED, it can then reverse it's Location
			if(getMode() != FRIGHTENED && currentDirection != null)
			{
				
				if(currentDirection == DOWN)
				{
					up = false;
				}
				else if(currentDirection == RIGHT)
				{
					left = false;
				} 
				else if(currentDirection == UP)
				{
					down = false;
				}
				else if(currentDirection == LEFT)
				{
					right = false;
				}
			}
			
			//Checking to see if test locations are a wall
			if(getMaze().isWall(upRow, upCol))
			{
				up = false;
			}
			if(getMaze().isWall(leftRow, leftCol))
			{
				left = false;
			}
			if(getMaze().isWall(downRow, downCol))
			{
				down = false;
			}
			if(getMaze().isWall(rightRow, rightCol))
			{
				right = false;
			}
			
			//Index of chosen nextLoc and nextDir
			int minIndex = 0;
			
			//Finding distances for each of the surrounding locations, if the location is not accessible will max out the value
			if(getMode() != FRIGHTENED && targetLocation != null)
			{
				//Getting the distance for each direction you go
				if(up) 
				{
					upLength = findLineLength(upLocation, targetLocation);
				}
				else
				{
					upLength = 2147483647;
				}
				if(left) 
				{
					leftLength = findLineLength(leftLocation, targetLocation);;
				}
				else
				{
					leftLength = 2147483647;
				}
				if(down)
				{
					downLength = findLineLength(downLocation, targetLocation);;
				}
				else
				{
					downLength = 2147483647;
				}
				if(right)
				{
					rightLength = findLineLength(rightLocation, targetLocation);;
				}
				else
				{
					rightLength = 2147483647;
				}
				
				
				//Going through the lengths to determine what location is closet
				double[] directionLengths = {upLength, leftLength, downLength, rightLength};
				
				double min = directionLengths[minIndex];
				
				for(int i = 1; i < 4; i++)
				{
					

					double diff = Math.abs(directionLengths[i] - min);
					
					//If the directions are within a certain number of error will not set the test location as the new nextLoc
					if((directionLengths[i] < min) && (diff > ERR))
					{
						minIndex = i;
						min = directionLengths[minIndex];
					}
					
				}
			
			}
			//If the ghost is in FRIGHTENED then choose random locations
			else
			{
				
				  int randomNumber = rand.nextInt(4);
				  
				  int directionRow = directionLocations[randomNumber].row();
				  int directionCol = directionLocations[randomNumber].col();
				  
				  boolean[] directionBoolean = {up, left, down, right};
				  
				  while(currentMaze.isWall(directionRow, directionCol) || !directionBoolean[randomNumber])
				  {
					  randomNumber = rand.nextInt(4);
					  directionRow = directionLocations[randomNumber].row();
					  directionCol = directionLocations[randomNumber].col();
				  }
				  
				  minIndex = randomNumber;

			}
			
			//Setting the new direction and location	
			nextDir = directions[minIndex];
			nextLoc = directionLocations[minIndex];
			
		}
	  	
	 
		public void calculateNextCell(Descriptor desc)
		{
			
			if(getMode() == INACTIVE)
			{
				
				//Do Nothing
				
			}
			
			if(getMode() == CHASE)
			{ 	
				
				setIncrement(getBaseIncrement());
				
				calculation(desc, findChaseTargetLocation(desc));
			
			}
			
			if(getMode() == DEAD)
			{
				
				setIncrement(getBaseIncrement() * 2);
				
				calculation(desc, getHomeLocation());
			
			}
			
			if(getMode() == SCATTER)
			{
				
				setIncrement(getBaseIncrement());
				
				calculation(desc, scatterLocation);

			}
			
			if(getMode() == FRIGHTENED)
			{
				
				setIncrement(getBaseIncrement() * (2.0 / 3));
				
				//Calling with null and in FRIGHTENED mode will cause it to choose random cells
				calculation(desc, null);
				
			}
			
			
			
			
		}
	  
	  //For specific ghosts to implement, CHASE mode target location algorithm
	  protected abstract Location findChaseTargetLocation(Descriptor d);
	  
	  public Location getNextCell()
	  {
		  return nextLoc;
	  }
	  
	  //For Character parent class implementing checks 
	  @Override
	  protected void preUpdateChecks(Descriptor d)
	  {
			//If you don't have a direction need to find where the next location should be and change direction towards that new location
			if (getCurrentDirection() == null && getMode() != null) 
			{
				
				calculateNextCell(d);

				setDirection(findCurrentDirection());
				// return;
			}

			if (nextDir == null) 
			{
				calculateNextCell(d);
			}
	  }
	  
	  //For ghosts checks to see if your cross over into the next cell
	  @Override
	  protected void potentialCellCheck(Descriptor d)
	  {
		  
		  if(getCurrentLocation().equals(nextLoc))
		    {
		    	
			  	calculateNextCell(d);
			  
		    }
	  
	  }
	  
	  //For update method where it is deciding whether or not to stop and this checks if you want to turn at upcoming midpoint and will return if you will be turning
	  @Override
	  protected boolean extraBoolean(double difference)
	  {
		  
		  Direction testDirection = getCurrentDirection();
		  return ((testDirection != nextDir || testDirection == null));
	  
	  }
	  
	  //Extra code that's run in the update function
	  @Override
	  protected void extraUpdateCode()
	  {

		  setDirection(nextDir);
		  
	  }
	  
	  //If these conditions are meant then the update function will return
	  @Override
	  protected boolean returnConditions()
	  {
		  return (getMode() == null || getMode() == INACTIVE);
	  }  
	  
}
