package hw4;

import java.util.Random;

import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

import static api.Direction.DOWN;
import static api.Direction.LEFT;
import static api.Direction.RIGHT;
import static api.Direction.UP;

/*
 * Pinky class
 * 
 * @author Joseph Schmidt
 * 
 */
public class Pinky extends Ghosts {
	
	public Pinky(MazeMap maze, Location home, double baseSpeed, Direction homeDirection, Location givenScatterTarget, Random givenRandomNumber)
	{
		
		super(maze, home, baseSpeed, homeDirection, givenScatterTarget, givenRandomNumber);
		
	}
	
	/*
	 * Implements the target location for Pinky when in CHASE mode. This location is 4 cells in front of Pacman.
	 */
	@Override
	protected Location findChaseTargetLocation(Descriptor d) {
		
		Location pacmanLocation = d.getPlayerLocation();
		Direction pacmanDirection = d.getPlayerDirection();
		int pacmanRow = pacmanLocation.row();
		int pacmanCol = pacmanLocation.col();
		
		if(pacmanDirection == UP)
		{
			pacmanRow -= 4;
		}
		else if(pacmanDirection == DOWN)
		{
			pacmanRow += 4;
		}
		else if(pacmanDirection == LEFT)
		{
			pacmanCol -= 4;
		}
		else
		{
			pacmanCol += 4;
		}
		
		Location fourInfrontPacman = new Location(pacmanRow, pacmanCol);
		
		return fourInfrontPacman;
		
	}

}
