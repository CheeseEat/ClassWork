package hw4;

import static api.Mode.INACTIVE;

import api.Actor;
import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

/*
 * Abstract class for Pacman and ghosts
 * 
 * @author Joseph Schmidt
 * 
 */
public abstract class Character implements Actor
{
	
	/**
	   * Margin of error for comparing exact position to centerline
	   * of cell.
	   */
	  public static final double ERR = .001;

	  /**
	   * Maze configuration.
	   */
	  private MazeMap maze;
	  
	  /**
	   * Initial location on reset().
	   */
	  private Location home;
	  
	  /**
	   * Initial direction on reset().
	   */
	  private Direction homeDirection;
	  
	  /**
	   * Current direction of travel.
	   */
	  private Direction currentDirection;
	  
	  /**
	   * Basic speed increment, used to determine currentIncrement.
	   */
	  private double baseIncrement;
	  
	  /**
	   * Current speed increment, added in direction of travel each frame.
	   */
	  private double currentIncrement;
	  
	  /**
	   * Row (y) coordinate, in units of cells.  The row number for the
	   * currently occupied cell is always the int portion of this value.
	   */
	  private double rowExact;
	  
	  /**
	   * Column (x) coordinate, in units of cells.  The column number for the
	   * currently occupied cell is always the int portion of this value.
	   */
	  private double colExact;
	  
	  /*
	   * Keeps track of the current mode for the Character
	   */
	  private Mode currentMode;
	  
	
	 /**
	   * Constructs a new Pacman with the given maze, home location, base speed,
	   * and initial direction.
	   * @param maze
	   *   maze configuration
	   * @param home
	   *   initial location
	   * @param baseSpeed
	   *   base speed increment
	   * @param homeDirection
	   *   initial direction
	   */
	  public Character(MazeMap maze, Location home, double baseSpeed, Direction homeDirection)
	  {
	    this.maze = maze;
	    this.home = home;
	    this.baseIncrement = baseSpeed;
	    this.currentIncrement = baseSpeed;
	    this.homeDirection = homeDirection;
	  }
	  
	  public MazeMap getMaze()
	  {
		  return maze;
	  }
	  
	  @Override
	  public double getBaseIncrement()
	  {
	    return baseIncrement;
	  } 
	  
	  @Override
	  public double getColExact()
	  {
	    return colExact;
	  }
	   
	  @Override
	  public Direction getCurrentDirection()
	  {
	    return currentDirection;
	  }
	  
	  @Override
	  public double getCurrentIncrement()
	  {
	    return currentIncrement;
	  }
	  
	  @Override
	  public Location getCurrentLocation()
	  {
	    return new Location((int) rowExact, (int) colExact);
	  }
	  
	  @Override
	  public Direction getHomeDirection()
	  {
	    return homeDirection;
	  }
	  
	  @Override
	  public Location getHomeLocation()
	  {
	    return home;
	  }
	  
	  @Override
	  public Mode getMode()
	  {
	    // does nothing for Pacman
	    return currentMode;
	  }
	  
	  @Override
	  public double getRowExact()
	  {
	    return rowExact;
	  }
	  
	  @Override
	  public void reset()
	  {
	    Location homeLoc = getHomeLocation();
	    setRowExact(homeLoc.row() + 0.5);
	    setColExact(homeLoc.col() + 0.5);
	    setDirection(getHomeDirection());
	    currentIncrement = getBaseIncrement();
	 
	  }

	@Override
	  public void setColExact(double c)
	  {
	    colExact = c;
	  }

	  @Override
	  public void setDirection(Direction dir)
	  {
	    currentDirection = dir;
	  }
	  
	  @Override
	  public void setMode(Mode mode, Descriptor desc)
	  {
		  currentMode = mode;
		  
	  }
	  
	  protected void setIncrement(double speed)
	  {
		  currentIncrement = speed;
	  }
	  
	  @Override
	  public void setRowExact(double r)
	  {
	    rowExact = r;
	  }
	  
	  
	  /*
	   * Updates the given character's position.
	   */
	 @Override
	  public void update(Descriptor d)
	  {
		 
		//Checks to see if the update function should return without updating 
		if (returnConditions()) 
		{
			return;
		}
		 
		//Checks before the update function begins
		preUpdateChecks(d);
	    
	    double increment = currentIncrement;
	    double curRowExact = getRowExact();
	    double curColExact = getColExact();
	    int rowNum = (int) curRowExact;
	    int colNum = (int) curColExact;   
	    
	    // distance to center of cell we are in, in the direction of travel, may be negative    
	    double diff = distanceToCenter();
	    
	    //Determining the current location of the Character
	    switch(currentDirection)
	    {     
	      

	      case LEFT:
	        // special case: check whether we are in the tunnel and need to wrap around
	        if (curColExact - increment - 0.5 < 0)
	        {
	          curColExact = maze.getNumColumns() + (curColExact - increment - 0.5);
	        }
	        else
	        {
	          // if we are approaching a wall, be sure we stop moving
	          // at the center of current cell.  This only applies when
	          // 'diff' is positive but small enough that we can't move a full
	          // increment
	          if (diff > -ERR && diff < increment && (maze.isWall(rowNum, colNum - 1) || extraBoolean(diff)))
	          {
	            
	        	extraUpdateCode();
	        	
	        	increment = diff;
	        	
	          
	          }
	          curColExact -= increment;         
	        
	        }
	        break;       
	      case RIGHT:
	        // special case: check whether we are in the tunnel and need to wrap around
	        if (curColExact + increment + 0.5 >= maze.getNumColumns())
	        {
	          curColExact = curColExact + increment + 0.5 - maze.getNumColumns();
	        }
	        else
	        {
	          if (diff > -ERR && diff < increment && (maze.isWall(rowNum, colNum + 1) || extraBoolean(diff))) 
	        		
	          {
	        	  
	        	  extraUpdateCode();
	        	  
	        	  increment = diff;
	        	  
	          }
	          curColExact += increment;
	        }
	        break;        
	      case UP:
	    	if (diff > -ERR && diff < increment && (maze.isWall(rowNum - 1, colNum) || extraBoolean(diff)))
	        {
	        	
	        	extraUpdateCode();
	        	
	        	increment = diff;
	        	
	        
	        }
	        curRowExact -= increment;       
	        break;
	      case DOWN:
	        if (diff > -ERR && diff < increment && (maze.isWall(rowNum + 1, colNum) || extraBoolean(diff)))
	        {
	        	
	        	extraUpdateCode();
	        	
	        	increment = diff;
	        	
	        
	        }
	        curRowExact += increment;
	        break;
	    }
	    
	    // finally, update instance vars
	    setRowExact(curRowExact);
	    setColExact(curColExact);
	    
	    potentialCellCheck(d);
	    
	  }
	 
	 /**
	   * Determines the difference between current position and center of 
	   * current cell, in the direction of travel.
	   */
	  protected double distanceToCenter()
	  {
	    double colPos = getColExact();
	    double rowPos = getRowExact();
	    switch (getCurrentDirection())
	    {
	      case LEFT:
	        return colPos - ((int) colPos) - 0.5;
	      case RIGHT:
	        return 0.5 - (colPos - ((int) colPos));
	      case UP:
	        return rowPos - ((int) rowPos) - 0.5;
	      case DOWN:
	        return 0.5 - (rowPos - ((int) rowPos));
	    }    
	    return 0;
	  } 
	 
	protected abstract boolean returnConditions();

	protected abstract void preUpdateChecks(Descriptor d);

	protected abstract void potentialCellCheck(Descriptor d);

	protected abstract boolean extraBoolean(double diff);

	protected abstract void extraUpdateCode();

	
}
