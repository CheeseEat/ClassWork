package hw4;

import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

import static api.Direction.DOWN;
import static api.Direction.LEFT;
import static api.Direction.RIGHT;
import static api.Direction.UP;

import java.util.Random;

/*
 * Inky class
 * 
 * @author Joseph Schmidt
 * 
 */
public class Inky extends Ghosts {
	
	
	public Inky(MazeMap maze, Location home, double baseSpeed, Direction homeDirection, Location givenScatterTarget, Random givenRandomNumber)
	{
		
		super(maze, home, baseSpeed, homeDirection, givenScatterTarget, givenRandomNumber);
		
	}
	

	/*
	 * Finds location for CHASE mode, finds the location from Blinky's current location and two in front of Pacman then that vector times by two.
	 */
	@Override
	protected Location findChaseTargetLocation(Descriptor d) {
		
		Location pacmanLocation = d.getPlayerLocation();
		Location blinkyLocation = d.getBlinkyLocation();
		Direction pacmanDirection = d.getPlayerDirection();
		int pacmanRow = pacmanLocation.row();
		int pacmanCol = pacmanLocation.col();
		int blinkyRow = blinkyLocation.row();
		int blinkyCol = blinkyLocation.col();
		
		if(pacmanDirection == UP)
		{
			pacmanRow -= 2;
		}
		else if(pacmanDirection == DOWN)
		{
			pacmanRow += 2;
		}
		else if(pacmanDirection == LEFT)
		{
			pacmanCol -= 2;
		}
		else
		{
			pacmanCol += 2;
		}
		
		int rowTarget = (pacmanRow - blinkyRow) * 2 + blinkyRow;
		int colTarget = (pacmanCol - blinkyCol) * 2 + blinkyCol;
		
		Location tempLocation = new Location(rowTarget, colTarget);
		
		return tempLocation;
	}

}
