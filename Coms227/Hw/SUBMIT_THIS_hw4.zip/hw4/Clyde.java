package hw4;

import static api.Mode.CHASE;
import static api.Mode.DEAD;
import static api.Mode.INACTIVE;
import static api.Mode.SCATTER;

import java.util.Random;

import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

/*
 * Clyde class
 * 
 * @author Joseph Schmidt
 */
public class Clyde extends Ghosts{
	
	public Clyde(MazeMap maze, Location home, double baseSpeed, Direction homeDirection, Location givenScatterTarget, Random givenRandomNumber)
	{
		
		super(maze, home, baseSpeed, homeDirection, givenScatterTarget, givenRandomNumber);
		
	}

	/*
	 * Implements the target location for Clyde when in CHASE mode. This location is Pacman's location until Clyde gets within 8 unit length. When Clyde 
	 * gets within this length his target location changes to his SCATTER location.
	 */
	@Override
	protected Location findChaseTargetLocation(Descriptor desc)
	{
		
		Location currentLocation = getCurrentLocation();
		Location pacmanLocation = desc.getPlayerLocation();
		Location scatterLocation = getScatterLocation();
		
		if(findLineLength(currentLocation, pacmanLocation) > 8)
		{
			return pacmanLocation;
		}
		else
		{
			return scatterLocation;
		}
		
			
	}
	
}
