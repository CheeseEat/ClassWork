package hw1;

/**
 * 
 * @author Joseph Schmidt
 * 
 * Class that will create a car stereo between a certain range of given frequencies. Also creates different amount of stations in the range of frequencies determined 
 * when constructing. Has volume for car radio as well. Different methods to change frequencies, channel numbers, and volume.
 *
 */
public class CarStereo {
	
	/**
	 * Holds the value for which volume changes upon increasing or decreasing the volume
	 */
	public static final double VOLUME_STEP = 0.16;
	
	/**
	 * holds the volume for a CarStereo object
	 */
	private double volume= 0.5;
	
	/**
	 * holds the current frequency for a CarStereo object
	 */
	private double frequency;
	
	/**
	 * The minimum frequency of the CarStereo
	 */
	private double minFrequency;
	
	/**
	 * The max frequency of the CarStereo
	 */
	private double maxFrequency;
	
	/**
	 * Number of stations wanted
	 */
	private int numStations;
	
	/**
	 * Current saved radio station number
	 */
	private int savedStation = 0;
	
	/**
	 * Constructor for the CarStereo Class. Frequency starts off at minimum frequency.
	 * 
	 * @param givenMinFrequency 
	 * The minimum frequency for the car radio
	 * 
	 * @param givenMaxFrequency
	 * The maximum frequency for the car radio
	 * 
	 * @param givenNumStations
	 * The amount of car stations wanted
	 */
	public CarStereo(double givenMinFrequency, double givenMaxFrequency, int givenNumStations) {
		frequency = givenMinFrequency;
		minFrequency = givenMinFrequency;
		maxFrequency = givenMaxFrequency;
		numStations = givenNumStations;
	}
	
	/**
	 * Gets the current volume
	 * @return
	 * Volume level
	 */
	public double getVolume() {
		return volume;
	}
	
	/**
	 * Increase the volume by VOLUME_STEP, but not going over 1.0
	 */
	public void louder() {
		double increasedVolume = volume + VOLUME_STEP;
		volume = Math.min(increasedVolume, 1.00);
	}
	
	/**
	 * Decreases the volume by VOLUME_STEP, but not going below 0.0
	 */
	public void quieter() {
		double decreasedVolume = volume - VOLUME_STEP;
		volume = Math.max(decreasedVolume, 0);
	}
	
	/**
	 * Returns the frequency to which this radio is currently tuned
	 * @return
	 * Current frequency
	 */
	public double getTuner() {
		return frequency;
	}
	
	/**
	 * Sets the tuner frequency to the given value if possible. If the given value is 
	 * above the maximum, the tuner is set to the max, and if below the min the tuner is 
	 * set to the minimum
	 * 
	 * @param givenFrequency
	 * sets tuner to given value. If exceeds the max will set to max instead. If falls below
	 * minimum will set to minimum instead.
	 */
	public void setTuner(double givenFrequency) {
		double tempFrequency = 0.0;
		tempFrequency = Math.min(givenFrequency, maxFrequency);
		tempFrequency = Math.max(tempFrequency, minFrequency);
		frequency = tempFrequency;
	}
	
	/**
	 * Adjusts the current tuner frequency by turning it by specified degrees. A full rotation 
	 * corresponds to the full band width (max frequency - min frequency), and any fraction
	 * rotation adjusts the frequency by the same fraction of the band width.
	 * 
	 * @param degrees
	 * Degrees to turn knob
	 */
	public void turnDial(double degrees) {
		
		double differenceFrequency = maxFrequency - minFrequency;
		double frequencyChanged = differenceFrequency * (degrees / 360);
		double newFrequency = frequencyChanged + frequency;
		
		newFrequency = Math.min(newFrequency, maxFrequency);
		newFrequency = Math.max(newFrequency, minFrequency);
		frequency = newFrequency;		
	
	}
	
	/**
	 * Sets the tuner to the broadcast frequency of given station if possible. If station is below
	 * zero, the tuner is set to broadcast frequency of station 0, if greater than or equal
	 * to the max channel number it sets it to the last channel.
	 * 
	 * @param stationNumber
	 * Desired station wanted
	 * 
	 */
	public void setTunerFromStationNumber(int stationNumber) {
		
		double frequencyDifference;
		double frequencyOfStationNumber;
		
		frequencyDifference = (maxFrequency - minFrequency) / numStations;
		frequencyOfStationNumber = minFrequency + (stationNumber * frequencyDifference) + (frequencyDifference / 2);
		
		frequencyOfStationNumber = Math.min(frequencyOfStationNumber, (maxFrequency - (frequencyDifference / 2)));
		frequencyOfStationNumber = Math.max(frequencyOfStationNumber, (minFrequency + (frequencyDifference / 2)));
		frequency = frequencyOfStationNumber;
	}
	
	/**
	 * 
	 * Determines the station number that is closet to the radio's current tuner frequency. If
	 * the tuner is at exactly the midpoint between two stations, rounds to the higher station 
	 * number; however, if the tuner is at the max frequency (which would normally round to
	 * station N) then N - 1 is returned (were N denotes the number of stations). 
	 * 
	 * @return
	 * Station number
	 */
	public int findStationNumber() {	
		
		double interval = (maxFrequency - minFrequency) / numStations;
		double differenceFrequency = frequency - (minFrequency + (interval / 2));
		double unroundedStation = differenceFrequency / interval;
		int roundedStation = (int) Math.round(unroundedStation);
		roundedStation = Math.min(roundedStation, numStations - 1);
		
		return roundedStation;
	
	}
	
	/**
	 * Sets the tuner to the broadcast frequency of the next station below the current one,
	 * wrapping around to station N - 1 if the current station is 0(where N denotes the number
	 * of stations)
	 */
	public void seekDown() {
		int stationNumber = findStationNumber();
		int newStationNumber = (stationNumber + numStations - 1) % numStations;
		setTunerFromStationNumber(newStationNumber);
	}
	
	/**
	 * Sets the tuner to the broadcast frequency of the the next station above the current 
	 * one, wrapping around to zero if the current station is the last available station
	 */
	public void seekUp() {
		int stationNumber = findStationNumber();
		int newStationNumber = (stationNumber + 1) % numStations;
		setTunerFromStationNumber(newStationNumber);
	}
	
	/**
	 * Stores the current station number as the preset.
	 */
	public void savePreset() {
		savedStation = findStationNumber();
	}
	
	/**
	 * Sets the frequency to be the broadcast frequency of the current preset station,
	 */
	public void goToPreset() {
		setTunerFromStationNumber(savedStation);
	}
	
}
