package mini1;
import java.util.Scanner;
/**
 * Some loop practice problems!
 */
public class LostInTheLoop
{
  /**
   * Private constructor disables instantiation.
   */
  private LostInTheLoop()
  {
    
  }
  
  /**
   * Returns the initial number of matching characters in
   * two strings, allowing for a certain number of mismatches.
   * In a memory game, the player is has to repeat a sequence of
   * characters in a given "target" string.  The score is the number 
   * of characters that are
   * correctly repeated before the first mistake. However, it is
   * also possible to allow a certain number of mistakes, as 
   * represented by the third parameter, to be skipped over
   * and ignored. This method returns the score, given the guessed
   * string, the target string, and the maximum number of mistakes.
   * For example, 
   * <ul>
   *   <li>for ("abcdefg", "abcxeyg", 0), the score is 3 
   *   <li>for ("abcdefg", "abcxeyg", 1), the score is 4 
   *   <li>for ("abcdefg", "abcxeyg", 2), the score is 5 
   *   <li>for ("abcdefg", "abcxdef", 10), the score is 3 
   * </ul>
   * The method return -1 if the strings do not have the same length.
   * @param s
   *   guessed string
   * @param t
   *   target string
   * @param maxMistakes
   *   number of mismatches allowed to skip
   * @return
   *   player score
   */
  public static int memoryGameChecker(String s, String t, int maxMistakes)
  {  
    
	int score = 0;
	
	for(int i = 0; i < s.length(); i++)
	{
		if(s.charAt(i) == t.charAt(i))
		{
			score++;
		} 
		else if (maxMistakes > 0)
		{
			maxMistakes--;
		}
		else
		{
			break;
		}
	}
	
	return score;
	  
  }
  
  /**
   * Returns a string constructed from the given string by removing
   * all runs of the same character.  For example,
   * <ul>
   *   <li>from "abbccccdeeef", return "abcdef"
   *   <li>from "aaabcccc", return "abc"
   * </ul>
   * If the given string is empty, returns an empty string.
   * @param s
   *   given string
   * @return
   *   new string obtained by eliminating runs of the same character
   */
  public static String compressRuns(String s)
  {
	  String output = "";
	  
	  if(s.length() > 0) output += s.charAt(0);
	  
	  for(int i = 1; i < s.length(); i++) 
	  {
		  
		  if(s.charAt(i) != s.charAt(i - 1)) 
		  {
			output += s.charAt(i);  
		  }
		  
	  }
	  
	  return output;
  }
  
  /**
   * Determines how many terms of the sum of reciprocal triangle
   * numbers are needed to get within a specified distance of 2.0.
   * The series 
   * <pre>
   * 1 + 1/3 + 1/6 + 1/10 + 1/15 + ...
   * </pre>
   * approaches arbitrarily close to 2.0 as more terms are added.
   * This method determines how many terms are needed
   * to obtain a sum that is within a given margin of error
   * of 2.0. The terms of the series are the reciprocals of the "triangle" 
   * numbers 1, 3, 6, 10, 15, 21 ... in which the nth term is 
   * the previous term plus n, e.g.,
   * <pre>
   *   3 =   1 + 2
   *   6 =   3 + 3
   *   10 =  6 + 4
   *   15 = 10 + 5
   *   21 = 15 + 6
   * </pre>
   * ... and so on.  Example: countTriangleNumberSum(0.4) returns 4, since
   * <pre>
   * 1 + 1/3 + 1/6 = 1.5
   * 1 + 1/3 + 1/6 + 1/10 = 1.6
   * </pre>
   * so four terms is within 0.4 of 2.0, but three terms is not 
   * close enough.
   * @param err
   *   given margin of error
   * @return
   *   number of terms
   */
  public static int countTriangleNumberSum(double err)
  {
    
	double currentSum = 1;
	int count = 2;
	double pastSum = 1;
	double sumDifference = 2 - currentSum;
	int index = 1;
	
	while(sumDifference > err)
	{
		pastSum += count;
		count++;
		index++;
		currentSum += 1/pastSum;
		sumDifference = 2 - currentSum;
	}
	  
    return index;
  }
  
  /**
   * Parses a string containing names and quiz scores, and
   * returns the name and score for the highest score.
   * For example, given the string "Steve 42 June 137 Guang 75",
   * the method returns the string "June 137" (where there is
   * exactly one space between the name and number).  You can
   * assume that the names do not contain any whitespace, and
   * that the given string is either empty or valid. If the
   * argument is an empty string, the method returns an empty
   * string.  If two or more names are associated with the 
   * same highest score, the first one is returned.
   * @param s
   *   given string of name and score pairs
   * @return
   *   string with name and score for highest score
   */
  public static String findHighestScore(String s)
  {
    String output = "";
    Scanner scnr = new Scanner(s);
    String tempString = "";
    int maxInt = 0;
    
    
	if(scnr.hasNext())
	{
    	tempString = scnr.next();
	    maxInt = scnr.nextInt();
	    output = tempString + " " + maxInt;
	}   
    
    while(scnr.hasNext()) 
    {
    	tempString = scnr.next();
    	int tempInt = scnr.nextInt();
    	if(tempInt > maxInt)
    	{
    		maxInt = tempInt;
    		output = tempString + " " + tempInt;
    	}
    }
    
    return output;
  }
  
  /**
   * Given a size n >= 1, prints a picture of a tree to standard output,
   * in the pattern shown below for n = 5.
   * <pre>    
        /\
       //\\
      ///\\\
     ////\\\\
    /////\\\\\
        || 
   *     
   * </pre>
   * Note that at the widest part of the tree the line should have no leading
   * spaces.  WARNING: in Java code you can't directly use the backslash
   * character as a literal value; the way you type a literal backslash
   * character is with TWO backslashes: '\\'.
   * 
   * @param n
   *   height of the tree, not including the trunk
   */
  public static void printTree(int n)
  {
	  for(int i = 1; i <= n; i++){
		  
		  String output = "";
		  
		  for(int j = 0; j < (n - i); j++) {
			  
			  output += " ";
			  
		  }
		  for(int s = 0; s < i; s++) {
			  
			  output += "/";
		  
		  }
		  for(int s = 0; s < i; s++) {
			  
			  output += "\\";
		  
		  }
		  /*for(int j = 0; j < (n - i); j++) {
			  
			  output += " ";
			  
		  }*/
		  
		  System.out.println(output);
		  
		  if(i == n)
		  {
			  String outputSecond = "";
			  
			  for(int p = 0; p < (n - 1); p++) {
				  outputSecond += " ";
			  }
			  
			  System.out.println(outputSecond + "||");
		  }
		  
	  }
	  
  }
  
  /**
   * Checks a guess for a secret word and returns a feedback string.
   * This algorithm is inspired by, but not the same as, that used
   * by the game Wordle.
   * The returned string is the same length as the guess, and the
   * character at index i is filled in as follows, where  
   * g_i, s_i, and r_i denote the character at position i in
   * the guess, the secret word, and the result string, respectively.
   * 
   * <ul>
   *   <li>if g_i matches s_i, then r_i is '*'
   *   <li>if g_i does not occur in the secret word at all, 
   *   then r_i is '-'
   *   <li>if g_i does not match s_i, but the secret word does
   *   have an unmatched occurrence of g_i, then r_i is '?'.
   *   (More precisely, an "unmatched occurrence" means that there is some 
   *   index j such that g_i is equal to s_j but g_j is not equal
   *   to s_j.)
   * </ul>
   * 
   * For example,
   * <pre>
   *   Guess:  "guess"
   *   Secret: "geese"
   *   Result: "*-**-"
   *   
   *   Guess:  "bobbly"
   *   Secret: "blobby"
   *   Result: "*??*?*"
   *   
   *   Guess:  "aabbbb"
   *   Secret: "abbcde"
   *   Result: "*-*???"
   * </pre>
   * (Aside to Wordle fans: note that the latter case differs from 
   * the algorithm actually
   * used by Wordle, which would return "*-*?--", because it would 
   * count the number of unmatched b's in the secret word and note 
   * that there is only one, so only the first incorrect b in the guess
   * is labeled with a question mark.  In this method we are ignoring
   * that subtlety.)
   * <p>
   * The method returns null if the two given strings are not the same length.
   * 
   * 
   * @param guess
   *   the guessed word
   * @param secret
   *   the secret word
   * @return
   *   result string with feedback for the guess
   */
  public static String wordGameChecker(String guess, String secret)
  {
	  
	  String output = "";
	  
	  if(guess.length() != secret.length())
	  {
		  return null;
	  }
	  
	  for(int i = 0; i < guess.length(); i++) {
		  
		  if(guess.charAt(i) == secret.charAt(i)) {
			  output += "*";
		  }
		  else if (wordGameFindingChar(guess.charAt(i), secret, guess))
		  {
			  output += "?";
		  } 
		  else 
		  {
			  output += "-";
		  }
		
	  }
	  
	  return output;   
  }
  
  private static boolean wordGameFindingChar(char c, String s, String charString)
  {
	  for(int i = 0; i < s.length(); i++) 
	  {
		  if(s.charAt(i) == c && charString.charAt(i) != c) {
			  return true;
		  }
	  }
	  
	  return false;
  }
  
  
  /**
   * Given a string, returns a new string obtained by successively removing 
   * all adjacent matching characters.  For example, given "abbc", the method
   * returns "ac", and given "abcddcbeffg", the method returns "aeg". 
   * Note that multiple iterations may be required for the latter; that
   * is, after removing the matching "dd" and "ff", the resulting
   * string is "abccbeg", which now has a matching pair "cc"; after removing
   * "cc", the string is "abbeg, which now has a matching pair "bb". 
   * You can assume that the given string contains alphabetic characters only.
   * @param s
   *   given string
   * @return
   *   string obtained by removing matching pairs of adjacent characters
   */
  
  //Go through entire string and see 
  public static String cancelAdjacentPairs(String s)
  {
	 
	 String output = "";
	 String q = s;
	  
	 while(isAdjacentPairs(q))
	 {
		 
		 for(int i = 0; i < q.length(); i++)
		 {
			  
			  char currentChar = q.charAt(i);
			  
			  if((i == q.length() - 1 || currentChar != q.charAt(i + 1)))
			  {
				  output += currentChar;
			  } else
			  {
				  i++;
				  continue;
			  }
			  
		 }
		 
		 q = output;
		 output = "";
	  
	 }
	 
	 if(q.equals("") && s.charAt(1) == s.charAt(0))
	 {
		 q += s.charAt(0);
	 }
	 
	 return q;
			  
  }
  
  private static boolean isAdjacentPairs(String s)
  {
	  for(int i = 0; i < s.length() - 1; i++)
	  {
		  if(s.charAt(i) == s.charAt(i + 1))
		  {
			  return true;
		  }
	  }
	  return false;
  }
}