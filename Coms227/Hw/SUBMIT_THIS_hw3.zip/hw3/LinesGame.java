package hw3;

import java.util.ArrayList;

import api.GridCell;
import api.Line;
import api.Location;
import api.StringUtil;
import api.CellType;

/**
 * Game state for a Lines game.
 */
public class LinesGame
{
	/**
	 * A GridCell for the given LinesGame, keeps track of the state of the game
	 */
	private GridCell[][] gameGrid;
	
	/**
	 * Keeps track of all of the current gameLines
	 */
	private ArrayList<Line> gameLines;
	
	/**
	 * The current line the player is using and adding locations to
	 */
	private Line currentLine;
	
	/**
	 * Keeps track of the moves for the given game
	 */
	private int moveCount = 0;
	
  /**
   * Constructs a LinesGame from the given grid and Line list.
   * This constructor does not do any error-checking to ensure
   * that the grid and the Line array are consistent. Initially
   * the current line is null.
   * @param givenGrid
   *   a 2d array of GridCell
   * @param givenLines
   *   list of Line objects
   */
  public LinesGame(GridCell[][] givenGrid, ArrayList<Line> givenLines)
  {
    gameGrid = givenGrid;
    gameLines = givenLines;
  }
  
  /**
   * Constructs a LinesGame from the given descriptor. Initially the
   * current line is null.
   * @param descriptor
   *   array of strings representing initial state
   */
  public LinesGame(String[] descriptor)
  {
	   gameGrid = StringUtil.createGridFromStringArray(descriptor);
	   gameLines = Util.createLinesFromGrid(gameGrid);
  }
  
  /**
   * Returns the number of columns for this game.
   * @return
   *  width for this game
   */ 
  public int getWidth()
  {
        return gameGrid[0].length;
  }
  
  /**
   * Returns the number of rows for this game.
   * @return
   *   height for this game
   */ 
  public int getHeight()
  {
    return gameGrid.length;
  }
  
  /**
   * Returns the current cell for this game, possibly null.
   * The current cell is just the last location, if any, 
   * in the current line, if there is one. Returns null
   * if the current line is null or if the current line
   * has an empty list of locations.
   * @return
   *   current cell for this game, or null
   *   
   */
  public Location getCurrentLocation()
  {
	  return currentLine.getLast();
  }
  
  /**
   * Returns the id for the current line, or -1
   * if the current line is null.
   * @return
   *   id for the current line
   */
  public int getCurrentId()
  {
    return currentLine.getId();
  }
  
  /**
   * Return this game's current line (which may be null).
   * @return
   *   current line for this game
   */
  public Line getCurrentLine()
  {
    return currentLine;
  }
  
  /**
   * Returns a reference to this game's grid.  Clients should
   * not modify the array.
   * @return
   *   the game grid
   */
  public GridCell[][] getGrid()
  {
    return gameGrid;
  }
  
  /**
   * Returns the grid cell at the given position.
   * @param row
   *   given row
   * @param col
   *   given column
   * @return
   *   grid cell at (row, col)
   */
  public GridCell getCell(int row, int col)
  {
    return gameGrid[row][col];
  }
  
  /**
   * Returns all Lines for this game.  Clients should not modify
   * the returned list or the Line objects.
   * @return
   *   list of lines for this game
   */ 
  public ArrayList<Line> getAllLines()
  {
    return gameLines;
  }
  
  /**
   * Returns the total number of moves.  A "move" means that a 
   * new Location was successfully added to the current line
   * in addCell.
   * @return
   *   total number of moves so far in this game
   */
  public int getMoveCount()
  {
    return moveCount;
  }
  
  /**
   * Returns true if all lines are connected and all
   * cells are at their maximum count.
   * @return
   *   true if all lines are complete and all cells are at max
   */ 
  public boolean isComplete()
  {
	    //Checking to see if all line are connected
	    for(int i = 0; i < gameLines.size(); i++)
	    {
	    	if(!gameLines.get(i).isConnected())
	    	{
	    		return false;
	    	}
	    }
	    
	    //Checking to see if all tills are maxed out
	    for(int row = 0; row < gameGrid.length; row++)
	    {
	    	
	    	for(int col = 0; col < gameGrid[0].length; col++)
	    	{
	    		
	    		if(!gameGrid[row][col].maxedOut())
	    		{
	    			return false;
	    		}
	    		
	    	}
	    
	    }
	    
	    return true;
    
  }
  
  /**
   * Attempts to set the current line based on the given
   * row and column.  When using a GUI, this method is typically 
   * invoked when the mouse is pressed. If the current line is 
   * already non-null, this method does nothing.
   * There are two possibilities:
   * <ul>
   *   <li>Any endpoint can be selected.  Selecting an 
   *   endpoint clears the line associated with that endpoint's id,
   *   and all cells that were previously included in the line are decremented.
   *   The line then becomes the current line, and the endpoint is incremented
   *   and placed on the line's list of locations as its only element.
   *   <li>A non-endpoint cell can be selected if it is not a crossing
   *   and if it is the last cell in some line.  That line then becomes
   *   the current line.
   * </ul>
   * If neither of the above conditions is met, or if the
   * current line is non-null, this method does nothing.
   * 
   * @param row
   *   given row
   * @param col
   *   given column
   */
  public void startLine(int row, int col)
  {
	if(currentLine == null)
	{
		
	  Line compareLine;
	  Location coordinates = new Location(row, col);
	  //Boolean for keeping track of whether or not this function will restart the line or not
	  boolean isEqualToEndpoints = false;
	  
	  //For loop searches for if the line is starting at an endpoint and if it finds a line with those endpoints sets it as the current line
	  for(int i = 0; i < gameLines.size(); i++)
	  {
		  //Setting current line to the found endpoints
		  compareLine = gameLines.get(i);
		  if(compareLine.getEndpoint(0).equals(coordinates) || compareLine.getEndpoint(1).equals(coordinates))
		  {
			  currentLine = compareLine;
			  isEqualToEndpoints = true;
		  }
		  
		  //Checks to see if the start line is the last point in a given line and find the index of it and sets it as the current line
		  ArrayList<Location> compareLineLocations = compareLine.getCells();
		  if(!compareLineLocations.isEmpty())
		  {
		  	  if(compareLine.getLast().equals(coordinates) && !(gameGrid[row][col].isCrossing()))
			  {
				  currentLine = compareLine;
			  }
	  	  }
	  }
	  
	  //If selecting endpoint will clear the line associated with it and will add the current endpoint as the only point for the line.
	  if(isEqualToEndpoints)
	  {
		  ArrayList<Location> currentLineLocations = currentLine.getCells();
		  
		  for(int j = 0; j < currentLineLocations.size(); j++)
		  {
			  Location tempLocation = currentLineLocations.get(j);
			  int tempRow = tempLocation.row();
			  int tempCol = tempLocation.col();
			  gameGrid[tempRow][tempCol].decrement();
		  }
		  
		  currentLine.clear();
		  currentLine.add(coordinates);
		  gameGrid[row][col].increment();	
		  
	  }
	  	
	}
  }

  /**
   * Sets the current line to null. When using a GUI, this method is 
   * typically invoked when the mouse is released.
   */
  public void endLine()
  {
    currentLine = null;
  }
  
  /**
   * Attempts to add a new cell to the current line.  
   * When using a GUI, this method is typically invoked when the mouse is 
   * dragged.  In order to add a cell, the following conditions must be satisfied.
   * Here the "current cell" is the last cell in the current line, and "new cell"
   * is the cell at the given row and column:
   * :
   * <ol>
   *   <li>The current line is non-null
   *   <li>The current line is not connected
   *   <li>The given row and column are adjacent to the location of the current cell
   *       (horizontally, vertically, or diagonally) and not the same as the current cell
   *   <li>The count for the new cell is less than its max count
   *   <li>If the new cell is a MIDDLE or ENDPOINT, then its id matches
   *   the id for the current line
   *   <li>Adding the new cell will not cause the line to re-trace any
   *   existing line (according to the result of Util.checkForLineSegment)
   *   <li>Adding the new cell to the line would not cross any existing line
   *   (according to the result of Util.checkForPotentialCrossing)
   * </ol>
   * If the above conditions are met, a new Location at (row, col) is added
   * to the current line and the cell count is incremented.  Otherwise, the 
   * method does nothing.  If a new location
   * is added to the current line, the move counter is increased by 1.
   * @param row
   *   given row for the new cell
   * @param col
   *   given column for the new cell
   */
  public void addCell(int row, int col)
  {
	  //Makes sure the line is started before adding a cell
	  if(currentLine != null)
		{
	      Location currentLocation = currentLine.getLast();
		  GridCell cellToMoveTo = gameGrid[row][col];
		  Location locationCellToMoveTo = new Location(row, col);
		  int currentRow = currentLocation.row();
		  int currentCol = currentLocation.col();
		  int rowDiff = Math.abs(currentRow - row);
		  int colDiff = Math.abs(currentCol - col);
		  
		  //Checks above commented conditions
		  if(!currentLine.isConnected() && 
		    ((rowDiff == 1 || rowDiff == 0) && (colDiff == 1 || colDiff == 0)) && 
			 !(currentLocation.equals(locationCellToMoveTo)) && 
		   	 !(cellToMoveTo.maxedOut()) && 
		   	  (currentLine.getId() == cellToMoveTo.getId() || cellToMoveTo.isCrossing() || cellToMoveTo.isOpen()) && 
		   	 !Util.checkForLineSegment(gameLines, currentLocation, locationCellToMoveTo) && 
			 !Util.checkForPotentialCrossing(gameLines, currentLocation, locationCellToMoveTo))
		  {
			  //Adds the location
			  currentLine.add(locationCellToMoveTo);
			  gameGrid[row][col].increment();
			  moveCount++;
		  }
		}
  }

  /**
   * Returns a string representation of this game.
   */
  public String toString()
  {
    String result = "";
    result += "-----\n";
    result += StringUtil.originalGridToString(getGrid());
    result += "-----\n";
    result += StringUtil.currentGridToString(getGrid(), getAllLines());
    result += "-----\n";
    result += StringUtil.allLinesToString(getAllLines());
    Line ln = getCurrentLine();
    if (ln != null)
    {
      result += "Current line: " + ln.getId() + "\n";
    }
    else
    {
      result += "Current line: null\n";
    }
    return result;
  }

}
