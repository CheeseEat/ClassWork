/*
 * acd.h
 *
 *  Created on: OCT 22, 2023
 *      Author: hpreacher, dripleyb
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <inc/tm4c123gh6pm.h>
#include "math.h"
#include "Timer.h"

extern volatile char adcFlag;
volatile short data;

/*
 * initializes adc to take in IR values and convert based on given average depth
 */
void adc_init(void);            //we might want to take a number of samples to take in this.

/*
 * fires off the IR scanner, returns normalized distance
 */
int adc_fire(void);
