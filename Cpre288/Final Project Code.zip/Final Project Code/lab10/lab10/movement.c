#include "movement.h"

// used to move the CyBot forward or backward by a certain distance, updates sensor data via pointer, might be a good idea to add a overload for speed or something
void driveStraight(double distance, enum frwdBack direction,
                   oi_t *sensor_data_ptr)
{
    double sum = 0;
    double obsSum = 0;            //stores distances traveled to avoid obstacles
    int timesTurned = 0;

    switch (direction)
    {

    case (forward):

        oi_setWheels(300, 300);    //set speed of right, left wheel, to 500, 500
        oi_update(sensor_data_ptr);
        while (sum <= distance)
        {                   //check if we have moved the specified distance

            oi_update(sensor_data_ptr);

            //check if an obsticle has been struck on left side, could maybe offload to separate function
            if ((sensor_data_ptr->bumpLeft) && (!(sensor_data_ptr->bumpRight)))
            {
                oi_setWheels(0, 0);
                timesTurned++; //count times turned to subtract from total at the end
                oi_setWheels(-250, -250);
                while (obsSum >= -BACKUPDISTANCE)
                {
                    oi_update(sensor_data_ptr);
                    obsSum += sensor_data_ptr->distance;
                }
                oi_setWheels(0, 0);
                obsSum = 0;
                turnDegree(right, 90, sensor_data_ptr); //turn to avoid
                oi_setWheels(250, 250);
                while (obsSum <= AVOIDDISTANCE)
                {
                    oi_update(sensor_data_ptr);
                    obsSum += sensor_data_ptr->distance;
                }
                oi_setWheels(0, 0);
                obsSum = 0;
                turnDegree(left, 90, sensor_data_ptr); //turn back to get pointed forward
                oi_setWheels(300, 300);                 //resume drive
                while (obsSum < OBJECTWIDTH && sum < distance)
                {
                    oi_update(sensor_data_ptr);
                    obsSum += sensor_data_ptr->distance;
                    sum += sensor_data_ptr->distance;
                }
                oi_setWheels(0, 0);
                turnDegree(left, 90, sensor_data_ptr);
                oi_setWheels(250, 250);
                while (obsSum <= AVOIDDISTANCE)
                {
                    oi_update(sensor_data_ptr);
                    obsSum += sensor_data_ptr->distance;
                }
                oi_setWheels(0, 0);
                turnDegree(right, 90, sensor_data_ptr);
                oi_setWheels(300, 300);
            }

            //check if an obstacle has been struck on right side (or both)
            if (sensor_data_ptr->bumpRight)
            {
                oi_setWheels(0, 0);
                timesTurned++;
                oi_setWheels(-250, -250);
                while (obsSum >= -BACKUPDISTANCE)
                {      //might be possible to replace this with recursivity
                    oi_update(sensor_data_ptr);
                    obsSum += sensor_data_ptr->distance;
                    /*
                     * sum -= sensor_data_ptr->distance;
                     */
                }
                oi_setWheels(0, 0);
                obsSum = 0;
                turnDegree(left, 90, sensor_data_ptr); //turn to avoid
                oi_setWheels(250, 250);
                while (obsSum <= AVOIDDISTANCE)
                {        //might be possible to replace this with recursivity
                    oi_update(sensor_data_ptr);
                    obsSum += sensor_data_ptr->distance;
                }
                oi_setWheels(0, 0);
                obsSum = 0;
                turnDegree(right, 90, sensor_data_ptr); //turn back to get pointed forward
                oi_setWheels(300, 300); //resume drive
                while (obsSum < OBJECTWIDTH && sum < distance)
                {
                    oi_update(sensor_data_ptr);
                    obsSum += sensor_data_ptr->distance;
                    sum += sensor_data_ptr->distance;
                }
                oi_setWheels(0, 0);
                turnDegree(right, 90, sensor_data_ptr);
                oi_setWheels(250, 250);
                while (obsSum <= AVOIDDISTANCE)
                {
                    oi_update(sensor_data_ptr);
                    obsSum += sensor_data_ptr->distance;
                }
                oi_setWheels(0, 0);
                turnDegree(left, 90, sensor_data_ptr);
                oi_setWheels(300, 300);
                sum -= 169 * timesTurned;
            }
            sum += sensor_data_ptr->distance;
        }


        oi_setWheels(0, 0);                     //set both wheels to 0, stop
        break;

    case (backward):

        oi_setWheels(-200, -200);
        while (sum >= -distance)
        {
            oi_update(sensor_data_ptr);
            sum += sensor_data_ptr->distance;
        }
        oi_setWheels(0, 0);

        break;

    }
}

// used to turn the CyBot left or right by a certain degree, updates sensor data via pointer
void turnDegree(enum leftRight direction, double degrees, oi_t *sensor_data_ptr)
{
double sum = 0;

switch (direction)
{

case (right):

    oi_setWheels(-100, 100);
    while (sum > -degrees + 5.0)
    {
        oi_update(sensor_data_ptr);
        sum += sensor_data_ptr->angle;
    }
    oi_setWheels(0, 0);

    break;

case (left):

    oi_setWheels(100, -100); //set right wheel to 250, left wheel to -250
    //assuming angle is not signed at first -> corrected as positive angles are to the left
    while (sum < degrees - 5.0)
    {
        oi_update(sensor_data_ptr);
        sum += sensor_data_ptr->angle;
    }
    oi_setWheels(0, 0);                     //stop bot

    break;

}
}
