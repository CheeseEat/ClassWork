#include "scan.h"
#include "open_interface.h"

#include "uart.h"
#include "movement.h"
#include "timer.h"
#include "button.h"
#include "lcd.h"

//removed some includes from lab 8

#define ERROR 3 //standardized error

typedef struct
{
    int sound_dist;
    int IR_dist;
    int objAngle;
    int width;
} object_t;

//double calibrate(double IRvalue) made pointless in lab 8
//{
//    return 131 * exp(-0.000981 * IRvalue); //this is for bot ?
//}

//float avg(float buffer[], int num_items) made pointless in lab 8
//{
//    double sum = 0.0;
//    double average = 0.0;
//    int i;
//    for (i = 0; i < num_items; i++)
//    {
//        sum += buffer[i];
//    }
//    average = sum / num_items;
//    return average;
//}

void printToPutty(char *text)
{
    int p;
    for (p = 0; text[p] != '\0'; p++)
    {
        uart_sendChar(text[p]);
    }
    return;
}

void findObstacles(object_t* arrObs, int* numberObjects)
{
    char outputString[40];
    int tempStartAngle = 0;
    int calculatedMiddle = 0;
    int prevDist = 0, angle = 0, tempWidth = 0;
    uint8_t countingWidthFlag = 0;
    float dist = 0.0;
    //float IRbuffer[3];


    scan_t scanData;

    oi_setWheels(0, 0); // stop initially tbs
    scan(0, &scanData); //set scanner to the right

    *numberObjects = 0;
    sprintf(outputString, "Angle \t Distance \r\n");
    printToPutty(outputString);

    // start scan use scanData's address for storage
    for (angle = 0; angle <= 180; angle += 2)
    {
        scan(angle, &scanData);
        dist = scanData.IR_val;                             //I changed this from its value in lab8

        //print out received angles and distances \t for tab
        sprintf(outputString, "%3d \t %3.lf\r\n", angle, dist);

        printToPutty(outputString);

        //init object
        if ((arrObs[0].IR_dist > 500 || arrObs[0].IR_dist < 0) && *numberObjects < 1)
        {
            //arrObs[0].sound_dist = dist;
            arrObs[0].IR_dist = dist;
            arrObs[0].objAngle = angle; //i is most recently used for angle, pardon my crimes
            arrObs[0].width = 0;
        }
        if (tempWidth > 30)
        {
            tempWidth = 0; //we're looking at a wall
            countingWidthFlag = 0;
        }

        if (((dist + ERROR) <= prevDist) && (*numberObjects < 5) && !countingWidthFlag) //(-)second check can be removed later
        {
            countingWidthFlag = 1;
            tempStartAngle = angle;
        }

        if (((dist - ERROR) >= prevDist) && countingWidthFlag)          //last time scan ran and crashed we noticed the crash occured on a positive edge
        {

            if ((dist < 65) && (tempWidth <= 30))
            {                                    //50-60cm range
                //f-pointers, originally was no parenthesis
                (*numberObjects)++;
                arrObs[*numberObjects].width = tempWidth;
                arrObs[*numberObjects].IR_dist = prevDist;
                calculatedMiddle = ((angle - tempStartAngle) / 2) + tempStartAngle;
                scan(calculatedMiddle, &scanData);
                arrObs[*numberObjects].objAngle = calculatedMiddle;
                arrObs[*numberObjects].sound_dist = scanData.sound_dist;
            }
            tempWidth = 0; //new object now
            countingWidthFlag = 0;
        }
        if (countingWidthFlag)
        { //if we are counting an object's width
            tempWidth += 2;
        }
        prevDist = dist;
    }
    printToPutty("sDone\n");

    /*
     * We have a list of the obstacles so now lets move to the smallest
     */
    int i = 0;
    double WidthToRound;
    for (i = 1; i < *numberObjects; i++)
    { //account for radial distance and convert to linear
        WidthToRound = 2.0 * sin((arrObs[i].width / 360.0) * M_PI) * arrObs[i].IR_dist;
        arrObs[i].width = WidthToRound;
    }


    sprintf(outputString, "Object# \t Angle \t \t Distance \tWidth \r\n");
    printToPutty(outputString);

    for (i = 1; i <= *numberObjects; i++)
    {
        sprintf(outputString, "%2.d \t \t %3.d \t \t %3.d \t \t %d\r\n", (i),
                arrObs[i].objAngle, arrObs[i].sound_dist,
                arrObs[i].width);
        printToPutty(outputString);
    }
    printToPutty("END\n");
    servo_free();
    return;
}

volatile char uart_data;  // Your UART interupt code can place read data here
volatile char uartFlag;       // Your UART interupt can update this flag
volatile char adcFlag = 0;
volatile char toggle = 0;   //setting to 0 means default mode is manual

void main()
{
//    char auto_continue = 0;
    int i = 0;
    int num_obstacles = 0;
    object_t obstacles[5];

    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);

    uart_init(115200);

    timer_init();
    lcd_init();
    scan_init(0b0111);
    button_init();
    init_button_interrupts();
    //servo_calibrate();}  //add back if not on 02 or 00 or 13

    //new cybot calibrations
    left_calibration_value = 20354;
    right_calibration_value = 48656;

    char outputString[40];

    //For keeping track of the degrees turned after a scan
    float current_degree = 90;
    float current_distance = 0;

//    right_calibration_value = 253750;       //cybot 3?
//    left_calibration_value = 1246000;
//
//    right_calibration_value = 327250;     //cybot 13
//    left_calibration_value = 1293250;     //cybot 13
//
//    right_calibration_value = 101500;    //cybot 02
//    left_calibration_value = 1477000;    //cybot 02
//
//    right_calibration_value = 259000;    //cybot 05
//    left_calibration_value = 1240750;    //cybot 05
//
//    right_calibration_value = 285250;    //cybot 00
//    left_calibration_value = 1214500;    //cybot 00

    while (1)
    {
        start: //used for a jump

        while (!uartFlag);          //wait for flag indicating new thing
        uartFlag = 0;
        if (toggle) //if map key received start scan (may never change from m)
        {

//            if (uart_data == 'h') {
//                auto_continue = !auto_continue;
//            }
            while(!uartFlag);
            uartFlag = 0;
            while(!(uart_data == 'h')){ //wait for 'h'
                if(uart_data == 't') {
                    goto start;
//                    sprintf();
//                    sendToPutty();
//
                } //if toggle then leave autonomous
            }

            findObstacles(obstacles, &num_obstacles);
            int smWidth = 500;
            int smIndx = 0;
            for (i = 1; i <= num_obstacles; i++) //check for thinnest object
            {
                if (obstacles[i].width < smWidth && obstacles[i].width > 0)
                {
                    smWidth = obstacles[i].width;
                    smIndx = i;
                }
            }

            while(!uartFlag);
            uartFlag = 0;
            while(!(uart_data == 'h')){
                if(uart_data == 't') {goto start;} //if toggle then leave autonomous
            }
            if(!smIndx){continue;}
            if (obstacles[smIndx].sound_dist <= 60) {continue;}
            char turned = 0;
            if (obstacles[smIndx].objAngle < 90)
            { //turn towards object of small
                driveStraight(110, forward, sensor_data); //drive towards object of small
                turnDegree(right, 90 - obstacles[smIndx].objAngle, sensor_data);
                turned = 110;
            }
            if (obstacles[smIndx].objAngle > 90)
            {
                driveStraight(110, forward, sensor_data); //drive towards object of small
                turnDegree(left, obstacles[smIndx].objAngle - 90, sensor_data);
                turned = 110;
            }

            int distanceToDrive = obstacles[smIndx].sound_dist * 10 - 180 - turned;
            driveStraight(distanceToDrive, forward, sensor_data); //drive towards object of small
        }

        else
        {
            //ADDED IF ELSE STATEMENTS SO THAT IT WOULD STOP WHEN NOT HOLDING DOWN BUTTON

            if (uart_data == 'w')
            {
                //driveStraight(100, forward, sensor_data);
                oi_setWheels(100, 100);
                timer_waitMillis(50);
                oi_update(sensor_data);

                if(sensor_data->bumpLeft)
                {
                    sprintf(outputString, "Left Bumper Hit, reversing \r\n");
                    printToPutty(outputString);
                    driveStraight(100, backward, sensor_data);
                    current_distance -= 100;

                    timer_waitMillis(1000);
                    sprintf(outputString, "Done Reversing \r\n");
                    printToPutty(outputString);
                }
                else if(sensor_data->bumpRight)
                {
                    sprintf(outputString, "Right Bumper Hit, reversing \r\n");
                    printToPutty(outputString);
                    driveStraight(100, backward, sensor_data);
                    current_distance -= 100;

                    timer_waitMillis(1000);
                    sprintf(outputString, "Done Reversing \r\n");
                    printToPutty(outputString);
                }
                else if(sensor_data->cliffFrontLeft)
                {
                    sprintf(outputString, "Cliff Front Left, reversing \r\n");
                    printToPutty(outputString);
                    driveStraight(200, backward, sensor_data);
                    current_distance -= 200;

                    timer_waitMillis(1000);
                    sprintf(outputString, "Done Reversing \r\n");
                    printToPutty(outputString);
                }
                else if(sensor_data->cliffFrontLeft)
                {
                    sprintf(outputString, "Cliff Front right, reversing \r\n");
                    printToPutty(outputString);
                    driveStraight(200, backward, sensor_data);
                    current_distance -= 200;

                    timer_waitMillis(1000);
                    sprintf(outputString, "Done Reversing \r\n");
                    printToPutty(outputString);
                }
                else if(sensor_data->cliffLeft)
                {
                    sprintf(outputString, "Cliff Left, reversing \r\n");
                    printToPutty(outputString);
                    driveStraight(200, backward, sensor_data);
                    current_distance -= 200;

                    timer_waitMillis(1000);
                    sprintf(outputString, "Done Reversing \r\n");
                    printToPutty(outputString);
                }
                else if(sensor_data->cliffRight)
                {
                    sprintf(outputString, "Cliff right, reversing \r\n");
                    printToPutty(outputString);
                    driveStraight(200, backward, sensor_data);
                    current_distance -= 200;

                    timer_waitMillis(1000);
                    sprintf(outputString, "Done Reversing \r\n");
                    printToPutty(outputString);
                }
                else if(sensor_data->cliffLeftSignal > 2500)
                {
//                    sprintf(outputString, "infared under left: %d \r\n", sensor_data->infraredCharLeft);
//                    printToPutty(outputString);
                    sprintf(outputString, "tape right, reversing \r\n");
                    printToPutty(outputString);
                    driveStraight(200, backward, sensor_data);
                    current_distance -= 200;

                    timer_waitMillis(1000);
                    sprintf(outputString, "Done Reversing \r\n");
                    printToPutty(outputString);
                }
                else if(sensor_data->cliffRightSignal > 2500)
                {
                    sprintf(outputString, "tape right, reversing \r\n");
                    printToPutty(outputString);
                    driveStraight(200, backward, sensor_data);
                    current_distance -= 200;

                    timer_waitMillis(1000);
                    sprintf(outputString, "Done Reversing \r\n");
                    printToPutty(outputString);
                }

                sprintf(outputString, "infared under left: %d \r\n", sensor_data->cliffLeftSignal);
                printToPutty(outputString);

                sprintf(outputString, "infared under right: %d \r\n", sensor_data->cliffRightSignal);
                printToPutty(outputString);


                current_distance += sensor_data -> distance;
                oi_setWheels(0, 0);

            }
            else if (uart_data == 'a')
            {
                //turnDegree(left, 15, sensor_data);
                oi_setWheels(50, -50);
                timer_waitMillis(50);
                oi_update(sensor_data);
                current_degree += sensor_data->angle;
                if(current_degree >= 360) current_degree = 0;
                oi_setWheels(0, 0);
            }
            else if (uart_data == 'd')
            {
                //turnDegree(right, 15, sensor_data);
                oi_setWheels(-50, 50);
                timer_waitMillis(50);
                oi_update(sensor_data);
                current_degree += sensor_data->angle;
                if(current_degree <= 0) current_degree = 360;
                oi_setWheels(0, 0);
            }
            else if (uart_data == 's')
            {
                //driveStraight(100, backward, sensor_data);
                oi_setWheels(-100, -100);
                timer_waitMillis(50);
                oi_update(sensor_data);
                current_distance += sensor_data -> distance;
                oi_setWheels(0, 0);
            }
            else if (uart_data == 'm') {
                findObstacles(obstacles, &num_obstacles);
                current_degree = 90;
                current_distance = 0;
            }
            else if(uart_data == 'l')
            {
                /// \brief Load song sequence
                /// \param An integer value from 0 - 15 that acts as a label for note sequence
                /// \param An integer value from 1 - 16 indicating the number of notes in the sequence
                /// \param A pointer to a sequence of notes stored as integer values
                /// \param A pointer to a sequence of durations that correspond to the notes
                //oi_loadSong(int song_index, int num_notes, unsigned char  *notes, unsigned char  *duration);

                //unsigned char notes[] = {60, 80, 120, 60, 50, 50, 96};
                //unsigned char notes[] = {60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70};
                //unsigned char notes[] = {54, 58, 62, 66, 54, 58, 62, 66, 60};
                //unsigned char notes[] = {50, 54, 58, 62, 50, 54, 58, 62, 56};
                unsigned char notes[] = {56, 60, 64, 68, 56, 60, 64, 68, 62};
                unsigned char duration[] = {20, 20, 20, 60, 20, 20, 20, 40, 20};

                oi_loadSong(0, 9, notes, duration);

                /// \brief Play song
                /// \param An integer value from 0 - 15 that is a previously establish song index
                oi_play_song(0);
            }
            else if (uart_data == 'p')
            {
                oi_close();
                oi_free(sensor_data);
                break;
            }

            sprintf(outputString, "Degree: %.1f Distance: %.1f \r\n", current_degree, current_distance);
            printToPutty(outputString);

        }

    }
    oi_close();
    oi_free(sensor_data);
}
