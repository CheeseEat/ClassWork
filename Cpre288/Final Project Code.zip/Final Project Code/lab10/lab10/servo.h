/*
 * servo.h
 *
 *  Created on: Nov 2, 2023
 *      Author: dripleyb
 */

#ifndef SERVO_H_
#define SERVO_H_

#include "timer.h"
#include "lcd.h"
#include "button.h"
#include "driverlib/interrupt.h"

//Set these before utilizing the servo
int left_calibration_value;
int right_calibration_value;

//Initializes the servo
void servo_init(void);

//Utilize this function to get the calibration values before using servo functionality
void servo_calibrate(void);

//Turns the servo to degree(180-0)
void servo_turn(char degree);

//Disable the connection to the servo, use this when finished moving for now.
void servo_free(void);

#endif /* SERVO_H_ */
