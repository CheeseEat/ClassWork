/*
 * servo.c
 *
 *  Created on: Nov 2, 2023
 *      Author: dripleyb
 */

#include "servo.h"

enum {left, right} direction;

//variables to store the current angle (state), and calibrated values
int STATE = 90;

//157 cycles for 1 degree?
char oneDeg = 157;
//5 times 1 one degree?
short fiveDeg = 157 * 5;        //needed a constant value so I changed to the value of oneDeg :/


void servo_init()
{
    SYSCTL_RCGCGPIO_R |= 0x2;           //enable timer on pb
    timer_waitMillis(1);
    GPIO_PORTB_DEN_R |= 0x20;            //digital enable b 0x20 = 0b100000
    //GPIO_PORTB_DIR_R |= 0x20;           //set b5 as OUTPUT first
    GPIO_PORTB_AFSEL_R |= 0x20; //set alternate function enabled to see if that's what's causing problems
    GPIO_PORTB_PCTL_R &= ~0xf00000;       //clear AF selection
    GPIO_PORTB_PCTL_R |= 0x700000;        //set alternate function

    SYSCTL_RCGCTIMER_R |= 0x2;
    TIMER1_CTL_R &= ~0xf00; //disable timer 1B 3rd hex should be 0101 so clear 1101
    TIMER1_CFG_R |= 0x4;               //select 16bit cfg
    TIMER1_TBMR_R &= ~0x10001;
    // 11th bit needs 1 pwm mode start high, bit 9 needs 1 interrupt(currently not set), bit 4 needs 0 to count down, bit 3 needs 1 pwm mode, bit 1 needs 1 and bit 0 needs 0 to periodic mode
    TIMER1_TBMR_R |= 0b100000001010;
    TIMER1_TBPR_R = 0x4;                //prescaler for initial count down value
    TIMER1_TBILR_R = 0xE200;                //initial count down value
    TIMER1_CTL_R |= 0x100; //both edge interrupt(did not turn on this time) and enable b 0101

    TIMER1_TBPMR_R = 0x4;
    TIMER1_TBMATCHR_R = 0x8440;
    timer_waitMillis(400);
//    GPIO_PORTB_AFSEL_R &= ~0x20;          //disable AFSEL to disable servo?
}

void servo_calibrate()
{
    button_init();
    lcd_init();
    direction = left;
    GPIO_PORTB_AFSEL_R |= 0x20;
    TIMER1_TBMATCHR_R = 0x8440;         //assuming this value centered servo to 90

    while (1)
    {
        //lcd_clear(); //clear screen before update

//        switch(direction){
//        case right:
//            lcd_puts("SW1: Move 1 degree");
//            lcd_gotoLine(2);
//            lcd_puts("SW2: Move 5 degrees");
//            lcd_gotoLine(3);
//            lcd_puts("SW3: Switch CCwise");
//            lcd_gotoLine(4);
//            lcd_puts("SW4: Move to 0");
//            break;
//
//        case left:
//            lcd_puts("SW1: Move 1 degree\n");
//            lcd_gotoLine(2);
//            lcd_puts("SW2: Move 5 degrees");
//            lcd_gotoLine(3);
//            lcd_puts("SW3: Switch Cwise");
//            lcd_gotoLine(4);
//            lcd_puts("SW4: Move to 180");
//            break;
//        }

        lcd_printf("%d", TIMER1_TBMATCHR_R);
        lcd_gotoLine(3);
        if (direction == left)
        {
            lcd_puts("Turning left");
        }
        else
        {
            lcd_puts("Turning right");
        }

        while (!(button_event)); //wait until a button has been pressed

        button_event = 0;

        switch (button_num)
        {
        case (0):
            break;

        case (1):
            //added conditionals here to make sure we don't go too nuts.
            if (direction == right && TIMER1_TBMATCHR_R < 0xBFFF)
            {
                TIMER1_TBMATCHR_R += oneDeg;
            }
            else if (TIMER1_TBMATCHR_R > 0x5000)
            {
                TIMER1_TBMATCHR_R -= oneDeg;
            }
            break;

        case (2):
            //also here
            if (direction == right && TIMER1_TBMATCHR_R < 0xBFFF)
            {
                TIMER1_TBMATCHR_R += fiveDeg;
            }
            else if (TIMER1_TBMATCHR_R > 0x5000)
            {
                TIMER1_TBMATCHR_R -= fiveDeg;
            }
            break;

        case (3):
            direction = (direction + 1) % 2;
            break;           //could also do !direction, or direction^ I believe

        case (4):
            if (direction == right)
            {
                TIMER1_TBMATCHR_R = 0xBE10;     ////this is on bot13
            }
            else
            {
                //cpre 288 in the timers?
                TIMER1_TBMATCHR_R = 0x4F84;     //this is on bot13
            }
            break;
        }

    }

}

void servo_turn(char degree)
{
    if (degree > 180) {return;}
    GPIO_PORTB_AFSEL_R |= 0x20;
//    short delta = STATE - degree;            //current position - new position abs for finding wait time
//    delta = abs(delta);
    //char waitTime = delta/180.0 * 400.0;        //wait time in milliseconds, we should really find the total time it takes to turn from 0 to 180 therabouts
    short waitTime = 350;

    //removed direction
    //do we even care about direction?


    TIMER1_TBMATCHR_R = right_calibration_value - (degree * oneDeg);   //Timer initial count value minus degrees times the clock cycles per one degree
    timer_waitMillis(waitTime);         //wait time proportional to distance moved
//    STATE = degree;
//    GPIO_PORTB_AFSEL_R &= ~0x20;        //disable servo
}

void servo_free()
{
    GPIO_PORTB_AFSEL_R &= ~0x20;
}
