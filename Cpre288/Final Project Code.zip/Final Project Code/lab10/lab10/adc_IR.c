/**
 * acd.c: Functions for input content.
 *
 *  @author hpeacher, dripleyb
 *  @date 10/22/2023
 *
 *
 */

#include <adc_IR.h>

void adc_interrupt_handler(void)
{
// STEP1: Check the Masked Interrup Status
    if (ADC1_ISC_R & ADC_ISC_IN1) {
//STEP2:  Copy the data
        data = ADC1_SSFIFO1_R;
        adcFlag = 1;
//STEP3:  Clear the interrupt
        ADC1_ISC_R |= ADC_ISC_IN1;
    }
}


void adc_init(void)
{            //we might want to take a number of samples to take in this.
    SYSCTL_RCGCGPIO_R |= 0x2;
    timer_waitMillis(1);
    GPIO_PORTB_DEN_R |= 0x10;
    GPIO_PORTB_DIR_R &= ~0x10;
    GPIO_PORTB_AMSEL_R |= 0x10;                 //analog mode select
    GPIO_PORTB_ADCCTL_R &= ~0xff;

    SYSCTL_RCGCADC_R |= 0x2;
    timer_waitMillis(1);
    ADC1_ACTSS_R &= ~ADC_ACTSS_ASEN1;           //disable adc
    timer_waitMillis(1);
    ADC1_EMUX_R &= ~0xf0;                       //clearing trigger for en1 (ss1) to default, so when program writes to mem reg it triggers conversion
    ADC1_SSMUX1_R &= 0xffff0000;                //clear all mux1 sequencers
    ADC1_SSMUX1_R |= 0xa;                       //sample bit 10 of  mux1
    ADC1_SSCTL1_R = 0x0006;                     //enable interrupt for first sample and first sample is last sample?
    ADC1_SAC_R |= 0x2;                          //this handles hardware averages, set for 4 point average
    ADC1_ACTSS_R |= ADC_ACTSS_ASEN1;            //ENABLE adc 1, bit 16 is busy signal for sample sequencer


    //interrupts pulled directly from the function
    // Enable interrupts for receiving bytes through ADC1 SS1
    ADC1_IM_R |= 0x2;                      //nnable RIS, ADD THIS BACK WHEN HANDLER IMPLEMENTED

    //NVIC enable register and bit responsible for ADC1 SS1
    NVIC_EN1_R |= 0x20000;

    //handle the interrupt using the interrupt number of ADC1 SS1 and handler
    IntRegister(INT_ADC1SS1, adc_interrupt_handler); //give the microcontroller the address of our interrupt handler - page 104 22 is the vector number
}

int calibrate(int IRvalue)
{
    //both are for bot 3
    //return (int)(2220000 * pow(IRvalue, -1.59)); //this is made with power functions was not good
    return (int)(124 * exp(IRvalue * -0.00116));
    //we took datapoints averaged 4 times at 5cm increments from 9 - 50cm, performed a best fit using exponential.
}

int adc_fire(void)
{
    ADC1_PSSI_R |= 0x2;
    while (ADC1_ACTSS_R & ADC_ACTSS_BUSY);
//    return calibrate((int)(ADC1_SSFIFO1_R & 0x0FFF)); //adcssfifo stores RAW value (send it back to the kitchen)
    return calibrate(data);
}
