

#include <ping.h>

/*
 * prelab
 *
 *1)
 * GPTMCTL  | TIMER3_CTL_R       //timer control
 * GPTMCFG  | TIMER3_CFG_R       //timer config
 * GPTMTBMR |                    //timer b mode
 * GPTMTBPR |                    //prescaler
 * GPTMTBILR|                    //interval load
 * GPTMMIS  |                    //masked interrupt status
 * GPTMIMR  | TIMER3_IMR_R       //interrupt mask register
 * GPTMICR  |                    //interrupt clear
 * GPTMRIS                       //raw interrupt
 *
 *
 *
 *2)
 * delta * 1 / clockrate / 2 * 340000
 *
 *3)
 * GPTMMIS is what sends an interrupt to the NVIC, GPTMRIS is what is read by an interrupt handler to determine which interrupt has happened
 */

void ping_interruptHandler(void) {
    //state = ((GPIO_PORTB_DATA_R >> 4) & 0b1);
    switch(state) {
    case LOW:
        pulseEnd = TIMER3_TBV_R;          //The prescaler is MSB /*TIMER3_TBPS_R << 32 + TIMER3_TBR_R*/
        state = DONE;
        break;
    case HIGH:
        pulseStart = TIMER3_TBV_R;        //TIMER3_TBPS_R << 32 + TIMER3_TBR_R;
        state = LOW;
        break;
    }
    TIMER3_ICR_R |= 0x400;              //clear capture mode interrupt
}

void ping_init(void) {
    SYSCTL_RCGCGPIO_R |= 0x2;           //enable timer on pb
    timer_waitMillis(1);
    GPIO_PORTB_DEN_R |= 0x8;            //digital enable b
    GPIO_PORTB_DIR_R |= 0x8;           //set b3 as OUTPUT first
    GPIO_PORTB_AFSEL_R |= 0x8;          //set alternate function enabled to see if that's what's causing problems
    GPIO_PORTB_PCTL_R &= ~0xf000;       //clear AF selection
    GPIO_PORTB_PCTL_R |= 0x7000;        //set alternate function as timer THIS WAS FUCKED

    SYSCTL_RCGCTIMER_R |= 0x8;
    TIMER3_CTL_R &= ~0x100;         //disable timer 3b
    timer_waitMillis(1);
    TIMER3_CTL_R |= 0xC00;          //timer 3b both edge detect c = 0b1100
    TIMER3_CFG_R |= 0x4;            //set timer 3 to 16bit split
    //alternatively it may be possible to store the number of edges that have occurred in edge count mode and then use that to find the distance, we will use edge time mode which stores the times of edge events
    TIMER3_TBMR_R |= 0x7;           //edge time, capture mode, maybe also pwm interrupt?
    TIMER3_TBMR_R &= ~0x10;         //make sure that we are in count down mode and in capture mode
    TIMER3_TBILR_R = 0xFFFF;       //part of prescaler for 24bit
    TIMER3_TBPR_R = 0xFF;          //part of prescaler
    TIMER3_CTL_R |= 0x100;

    //I don't see a way to easily average this

    //interrupts pulled from their function
    NVIC_EN1_R |= 0x10;                 //enable timer3b 16bit interrupt
    TIMER3_ICR_R |= 0x400;              //clear capture mode interrupt
    TIMER3_IMR_R |= 0x400;              //unmask capture mode interrupt
    IntMasterEnable();
    IntRegister(INT_TIMER3B, ping_interruptHandler);
}

void ping_echo(void) {
    TIMER3_IMR_R &= ~0x400;             //mask interrupt
    GPIO_PORTB_AFSEL_R &= ~0x8;         //disable AF

    GPIO_PORTB_DIR_R |= 0x8;            //set b3 as output
    GPIO_PORTB_DATA_R &= ~0b1000;       //clear data of b3
    GPIO_PORTB_DATA_R |= 0b1000;        //set high b3

    timer_waitMicros(5);                //leave high for 5us

    GPIO_PORTB_DATA_R &= ~0b1000;       //clear data of b3
    GPIO_PORTB_DIR_R &= ~0x8;           //set b3 as input
    state = HIGH;

    GPIO_PORTB_AFSEL_R |= 0x8;          //enable AF
    TIMER3_ICR_R |= 0x400;              //clear capture mode interrupt
    TIMER3_IMR_R |= 0x400;              //unmask capture mode interrupt
}

double ping_value(void) {
    ping_echo();
    while(state != DONE);
    unsigned int delta = pulseStart - pulseEnd;
    //return delta;
    return ( (float) ((delta/2.0 * (34000.0 / 16000000.0))));//to demonstrate part 2
}
