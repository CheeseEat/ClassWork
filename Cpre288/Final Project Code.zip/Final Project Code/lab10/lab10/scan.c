/*
 * scan.c
 *
 *  Created on: Nov 9, 2023
 *      Author: dripleyb
 */

#include "scan.h"

char initOptions = 0;

// Name: cyBOT_init_Scan
// Input: feature, int where each feature is associated with a bit as follows
//  Bit 0: 1 enable servo
//  Bit 1: 1 enable PING
//  Bit 2: 1 enable IR
//  Bit 3 - 7: Reserved (set to 0's)
// Example: cyBOT_init_Scan(0b0111); // Enables servo, PING, and IR
void scan_init(char options) {

    if (options & 0b001) {
        servo_init();
        initOptions |= 0b1;
    }
    if (options & 0b010) {
        ping_init();
        initOptions |= 0b10;
    }
    if (options & 0b100) {
        adc_init();
        initOptions |= 0b100;
    }
}

// Point sensors to angle, and get a scan value
// Input Parameters:
// angle: Direction to point the Sensors for taking a measurement
// getScan : The location of a declared cyBOT_Scan_t structure
// NOTE 1: If PING is not enabled, then getScan.sound_dist returns -1.0
// NOTE 2: If IR is not enabled, then getScan.IR_raw_val returns -1
void scan(char angle, scan_t* getScan) {
    if (initOptions & 0b001) {      //servo
        servo_turn(angle);
    }
    if (initOptions & 0b010) {      //ping
        getScan->sound_dist = ping_value();
    }
    if (initOptions & 0b100) {      //IR
        getScan->IR_val = adc_fire();
    }
}


