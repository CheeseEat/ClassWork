/*
 * lab9ping.h
 *
 *  Created on: Oct 26, 2023
 *      Author: dripleyb
 */

#ifndef PING_H_
#define PING_H_

#include "timer.h"
#include "lcd.h"
#include "driverlib/interrupt.h"

volatile enum {LOW, HIGH, DONE} state;
volatile unsigned int pulseStart;
volatile unsigned int pulseEnd;


void ping_init(void);

void ping_echo(void);

double ping_value(void);

#endif /* PING_H_ */
