#include <stdio.h>
#include "open_interface.h"

#define BACKUPDISTANCE 150
#define AVOIDDISTANCE 250
#define OBJECTWIDTH 500

enum frwdBack {forward, backward};
enum leftRight {left, right};

//used to move the CyBot forward or backward by a certain distance
void driveStraight(double distance, enum frwdBack direction, oi_t *sensor_data_ptr);

//used to turn the CyBot left or right by a certain degree
void turnDegree(enum leftRight direction, double degrees, oi_t *sensor_data_ptr);
