//
///**
// * How does the servo motor work? For example, what are the pulse widths necessary for full clockwise, center, and full counter-clockwise positions? (1pt)
// *  its circuit uses an op-amp to compare the (average) voltage received to 2.5 and if it's greater it rotates to the left of the middle position until voltages are equal, if it's
// *  less it rotates to the right until the voltage is equal, then if it's average is 2.5 it rotates to 90. 1milisec for 0deg, 1.5mili for 90, 2mili for 180
// *
// * What Timer1 registers are relevant to this lab? (2pts)
// *
// *  GPTMCFG
// *  GPTMT1MR
// *  GPTMCTL
// *  GPTMT1PR
// *  GPTMT1ILR
// *  GPTMT1MATCHR
// *  GPTMT1R
// *
// * With a Timer running at the 16 MHz system clock, how many timer ticks are there in 20ms duration? (1pt)
// *
// *  320000
// *
// * Describe timer programming for the PWM signal in terms of the high pulse and the low pulse. When is the output pin set? When is the output pin cleared? (1pt)
// *  The counter outputs a high PWM signal when it starts from a start value
// *  It stays high until the current counter value equals a match value, it then goes low and stays low until the counter reaches 0.
// *
// *
// */
//
//#include "servo.h"
//
//
//
//int main(void)
//{
////    leftMAX = 282500;     //these were deterimed exprimentally, correspond to 2.34375 miliseconds from start
////    rightMIN = 310800;    //correspond to 0.575 miliseconds from start
//
//    left_calibration_value = 20354;
//    right_calibration_value = 48656;
//
//    lcd_init();
//    servo_init();
//    servo_calibrate();
//    //servo_turn(90);
//}
