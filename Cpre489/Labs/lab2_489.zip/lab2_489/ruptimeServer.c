#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include <stdlib.h>

void main()
{

    int portNum = 8080;
    //int serverAddr = 

    
    //create socket
    int sock = socket(PF_INET, SOCK_STREAM, 0);

    if(sock == -1)
    {
        printf("socket failed\n");
    }
    else
    {
        printf("socket successful!\n");
    }

    //binding
    struct sockaddr_in addr;
    addr.sin_family = PF_INET;
    addr.sin_port = htons(portNum);
    //addr.sin_addr.s_addr = inet_addr(ipDest);
    addr.sin_addr.s_addr = INADDR_ANY;
    //int bind_status = bind(sock, &addr, sizeof(serverAddr));
    int bind_status = bind(sock, (struct sockaddr*) &addr, sizeof(addr));

    if(bind_status == -1)
    {
        printf("bind failure\n");
    }
    else
    {
        printf("bind succesful!\n");
    }

    //To keep the server listening
    while(1)
    {
    
        //listen
        int listen_status;
        listen_status = listen(sock, 3); 

        if(listen_status == -1)
        {
            printf("listen failed\n");
        }
        else
        {
            printf("Listening...\n");
        }

        //accept new socket
        struct sockaddr_in client_addr;
        int client_addr_len = sizeof(client_addr);
        int accepted_socket = accept(sock, (struct sockaddr*)&client_addr, &client_addr_len);

        if(accepted_socket == -1)
        {
            printf("accept failed\n");
        }
        else
        {
            printf("Accept successful!\n");
        }

        //recieve message
        char recieved_message[100];

        int read_bytes = read(accepted_socket, recieved_message, 100);

        if(read_bytes == -1)
        {
            printf("recieve fail\n");
        }
        else
        {
            printf("read %d bytes\n", read_bytes);
            printf("recieved message: %s\n", recieved_message);
        }

        //getting uptime
        FILE *fp;

        char send_string[100];

        fp = popen("uptime", "r");
        if(fp==NULL)
        {
            perror("Error: no such file or directory");
            exit(EXIT_FAILURE);
        }

        //read output
        if(fgets(send_string, sizeof(send_string), fp) == NULL)
        {
            perror("fgets");
            exit(EXIT_FAILURE);
        }

        if(pclose(fp) == -1)
        {
            perror("pclose");
            exit(EXIT_FAILURE);
        }

        int sent_bytes = write(accepted_socket, send_string, strlen(send_string) + 1);

        if(sent_bytes == -1)
        {
            printf("send failed\n");
        }
        else
        {
            printf("sent %d bytes\n", sent_bytes);
        }

        //close client socket
        int close_status = close(accepted_socket);
        
        if(close_status == -1)
        {
            printf("failed to close socket\n");
        }
        else
        {
            printf("socket closed.\n");
        }
    
    }
}