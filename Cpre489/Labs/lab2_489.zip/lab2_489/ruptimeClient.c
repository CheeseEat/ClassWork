#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>

void main(int argc, char *argv[])
{

    if(argc != 2)
    {
        printf("invald format");
        return;
    }

    int portNum = 8080;
    //char* ipDest = "192.168.254.24";
    //char* ipDest = "127.0.0.1";
    char* ipDest = argv[1];

    //create socket
    int sock = socket(PF_INET, SOCK_STREAM, 0);

    if(sock == -1)
    {
        printf("socket failure\n");
    }
    else
    {
        printf("socket successful!\n");
    }

    //connect to server
    struct sockaddr_in addr;
    addr.sin_family = PF_INET;
    addr.sin_port = htons(portNum);
    addr.sin_addr.s_addr = inet_addr(ipDest);

    int connect_status = connect(sock, (struct sockaddr*) &addr, sizeof(addr));

    if(connect_status == -1)
    {
        printf("connect failure\n");
    }
    else
    {
        printf("connect successful!\n");
    }

    //send message
    char send_string[45];
    printf("Enter message to server:\n");
    scanf("%s", send_string);

    int sent_bytes = write(sock, send_string, strlen(send_string) + 1);

    if(sent_bytes == -1)
    {
        printf("failed write\n");
    }
    else
    {
        printf("Wrote %d bytes\n", sent_bytes);
    }

    //recieve message
    char recieved_message[100];

    int read_bytes = read(sock, recieved_message, 100);

    if(read_bytes == -1)
    {
        printf("failed revieve\n");
    }
    else
    {
        printf("Read %d bytes\n", read_bytes);
        printf("recieved message: %s %s\n", ipDest, recieved_message);
    }

    //close socket
    int close_status = close(sock);

    if(close_status == -1)
    {
        printf("socket failed to close\n");
    }
    else
    {
        printf("socket closed.\n");
    }

}