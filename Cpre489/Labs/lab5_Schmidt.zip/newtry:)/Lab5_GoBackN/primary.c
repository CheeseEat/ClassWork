#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <stdlib.h>
#include "ccitt16.h"
#include "utilities.h"
#include "introduceerror.h"

#ifndef max
	#define max(a,b) ((a) > (b) ? (a) : (b))
#endif

void shiftWindowJoe(int win[])
{
	for(int p = 1; p < 3; p++)
	{
		win[p] = win[0] + p;
	}
}

void plusoneWindow(int win[])
{
	for(int p = 1; p < 3; p++)
	{
		win[p] = win[p] + 1;
	}
}


char sentPackets[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
int window[3] = {0, 1, 2};

unsigned char data[2] = {65, 66};
unsigned char tempdata[2];
unsigned char packet[6];

int transmissionAttempt =0;


void sendUnsent(int sockfd, double ber)
{
	for(int k = 0; k <= window[2]; k++)
	{
		//printf("send unsent: %d", k);
		// if(!sentPackets[k])
		// {
			//printf("didn't send: %d", k);
			sentPackets[k] = 1;

			tempdata[0] = data[0] + (2 * k);
			tempdata[1] = data[1] + (2 * k);
			buildPacket(packet, 1, tempdata, k);

			// printf("ACK recieved sending: %d", k);
			// printPacket(packet);

			IntroduceError(packet, ber);

			if(k == window[2])
			{
				printf("ACK recieved sending: %d", k);
				printPacket(packet);
			}

			if (send(sockfd, packet, strlen(packet), 0) < 0)
				perror("Send failed");
			
			transmissionAttempt++;
		//}
	}
}

/* The primary client/sender function
 * sockfd - the bound TCP socket (already set up) to communicate
 * 					with the secondary
 * ber 		- bit error rate which must be passed to IntroduceError */
void primary(int sockfd, double ber)
{
	int read_size;
	char msg[100], srv_reply[150];

	

	// keep communicating with server
	// while (1)
	// {
		// printf("Enter message : ");
		// fgets(msg, 100, stdin);

		// // Send some data to the receiver
		// // msg - the message to be sent
		// // strlen(msg) - length of the message
		// // 0 - Options and are not necessary here
		// // If return value < 0, an error occured
		// if (send(sockfd, msg, strlen(msg), 0) < 0)
		// 	perror("Send failed");

		for(int i = 0; i < 3; i++)
		{
			tempdata[0] = data[0] + (2 * window[i]);
			tempdata[1] = data[1] + (2 * window[i]);
			buildPacket(packet, 1, tempdata, window[i]);

			printf("for loop sending : \n");
			printPacket(packet);

			if (send(sockfd, packet, strlen(msg), 0) < 0)
				perror("Send failed");
			
			sentPackets[i] = 1;

		}

		while(window[2] <= 13) //window[2] is what you always send out once it reaches 14 it's done
		{
			if ((read_size = recv(sockfd, srv_reply, 149, 0)) < 0)
			{
				perror("recv failed");
			}
			else
			{
				printPacket(srv_reply);
			}

			if(srv_reply[0] == 2) //ACK
			{
				
				printf("window 0: %d\n", window[0]);
				printf("window 1: %d\n", window[1]);
				printf("window 2: %d\n", window[2]);
				// if(srv_reply[1] > window[0])
				// {
				
				window[0] = max(srv_reply[1], window[0]);
				shiftWindowJoe(window);

				printf("max window 0: %d\n", window[0]);
				printf("max window 1: %d\n", window[1]);
				printf("max window 2: %d\n", window[2]);

				sendUnsent(sockfd, ber);

				//shiftWindowJoe(window, srv_reply[1]);

				//}
			}
			else if(srv_reply[0] == 3) //NAK
			{
				// if(srv_reply[0] >= window[0]) //If NAK is less than the current window then something is wrong
				// {
					for(int k = 0; k < 3; k++)
					{
						tempdata[0] = data[0] + (2 * window[k]);
						tempdata[1] = data[1] + (2 * window[k]);

						buildPacket(packet, 1, tempdata, window[k]);

						printf("NAK recieved sending: %d", window[k]);
						printPacket(packet);

						IntroduceError(packet, ber);

						transmissionAttempt++;

						if (send(sockfd, packet, strlen(packet), 0) < 0)
							perror("Send failed");	

					}
				//}
			}
			else	//error
			{

			} 

		}

		// Receive a reply from the server
		// NOTE: If you have more data than 149 bytes, it will
		// 			be received in the next call to "recv"
		// read_size - the length of the received message
		// 				or an error code in case of failure
		// msg - a buffer where the received message will be stored
		// 149 - the size of the receiving buffer (any more data will be
		// 		delievered in subsequent "recv" operations
		// 0 - Options and are not necessary here
		// if ((read_size = recv(sockfd, srv_reply, 149, 0)) < 0)
		// 	perror("recv failed");

		// Null termination since we need to print it
		srv_reply[read_size] = '\0';
		printf("Server's reply: %s\n", srv_reply);
		printf("attempts: %d", transmissionAttempt);
	//}
}


