void IntroduceError(char *data, double p);
